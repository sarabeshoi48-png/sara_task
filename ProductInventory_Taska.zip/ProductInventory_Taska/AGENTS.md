# AGENTS.md

## Project References
- Requirements & scope: [docs/SRS.md](./docs/SRS.md), [Product_Inventory_System_Assessment.pdf](./Product_Inventory_System_Assessment.pdf)
- Class design specs: [docs/CLASSES_SPECS.md](./docs/CLASSES_SPECS.md)

## Tech Stack & EF Core Rules
- Build with **ASP.NET MVC**, **Entity Framework Core**, and **SQL Server** (`NFR-01`).
- Configure `Product` via Fluent API in a dedicated `IEntityTypeConfiguration<Product>` class (`NFR-01`).
- Store `ProductCategory` enum (`Electronics`, `Grocery`, `Clothing`, `Stationery`, `Other`) as `string` in the database, not `int` (`BR-06`).
- Configure `Price` with precision `(18,2)` (`BR-04`), unique index on `SKU` (`BR-02`), and database-side default values for `IsActive` (`true`) and `CreatedAt` (current date) (`BR-09`).
- Apply EF Core Migrations (`NFR-01`, `NFR-05`).

## Architecture & Dependency Injection
- Use Repository Pattern with `IProductRepository` and `ProductRepository` — **do not** use a Generic Repository (`NFR-02`, Out of Scope).
- Register dependencies via Dependency Injection in `Program.cs` (`NFR-02`).
- Use **N-Tier**, three projects (`NFR-03`) — **do not** introduce Microservices or Clean Architecture. Dependencies go one way: `Web` → `BLL` → `DAL`.
  - `DAL`: `Entities/`, `Enums/`, `Context/AppDbContext`, `Configurations/`, `Migrations/`, `Repositories/` (`IProductRepository`, `ProductRepository`, `PageData`). References no other project.
  - `BLL`: `Interfaces/IProductService`, `Services/ProductService`, `DTOs/ServiceResult`, `ViewModels/`, `Validation/`. References `DAL`.
  - `Web`: Controllers, Views, `wwwroot`, `Program.cs`. Uses `DAL` only for DI registration in `Program.cs` and for the `ProductCategory` enum.
- Business rules (`BR-xx`) live in `ProductService` (and the ViewModel attributes it validates), never in controllers or views. Write the rule number in a comment next to the code that applies it.
- Queries (filtering, search, sorting, paging) live in `ProductRepository`. Paging uses `ToPageAsync` in `DAL/Repositories/PageData.cs`. Page size is 10.
- `PL` (Controllers/Views) must talk to `BLL` (`IProductService`) only and **never** directly to `DbContext` or `IProductRepository` (`NFR-03`).

## Scope & Validation Rules
- **MVP (`FR-01`–`FR-06`, `BR-01`–`BR-10`)**:
  - Product CRUD (`List`, `Get by ID`, `Create`, `Update`, `Delete`), returning `NotFound` when `Id` does not exist (`BR-10`).
  - Enforce both Client-side and Server-side validation (`FR-06`) with clear errors (including duplicate `SKU`).
  - Field rules: `Name` required max `100`; `SKU` required max `20` unique; `Description` optional max `500`; `Price > 0`; `StockQuantity >= 0`; `ExpiryDate` not in the past and required when `Category == Grocery` (`BR-01`–`BR-08`).
- **Later (`FR-07`–`FR-11`, `BR-11`–`BR-13`)**:
  - Search by `Name`/`SKU` and filter by `Category`, Low stock list (`StockQuantity < 5`), Restock action (`quantity > 0`), Soft delete (`IsActive = false`, hidden from list), Pagination.
- **Out of Scope**:
  - Generic Repository, Authentication/Authorization/Roles, Sales/Orders/Invoices/Payments, Suppliers/Purchase Orders, Multi-store, Analytics/Exports, Audit Trail, Automated Notifications, separate mobile/external APIs.

## Required Documentation (`NFR-05`)
- Document how Repository and DI are applied, how CRUD operations work, and where/how every validation rule (including the `Grocery` rule) is enforced.
