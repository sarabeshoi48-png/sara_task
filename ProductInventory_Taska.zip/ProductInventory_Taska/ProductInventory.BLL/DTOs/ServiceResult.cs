namespace ProductInventory.BLL.DTOs;

/// <summary>
/// Outcome of a BLL service operation, carrying optional field-level error or not-found state.
/// </summary>
public sealed class ServiceResult
{
    public bool Succeeded { get; }

    public string? FieldName { get; }

    public string? ErrorMessage { get; }

    public bool IsNotFound { get; }

    private ServiceResult(
        bool succeeded,
        string? fieldName = null,
        string? errorMessage = null,
        bool isNotFound = false)
    {
        Succeeded = succeeded;
        FieldName = fieldName;
        ErrorMessage = errorMessage;
        IsNotFound = isNotFound;
    }

    public static ServiceResult Success() => new(true);

    public static ServiceResult Failure(string errorMessage, string? fieldName = null) =>
        new(false, fieldName, errorMessage);

    public static ServiceResult NotFound(string? errorMessage = null) =>
        new(false, null, errorMessage, isNotFound: true);
}
