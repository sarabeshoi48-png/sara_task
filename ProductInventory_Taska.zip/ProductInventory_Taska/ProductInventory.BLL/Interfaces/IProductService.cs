using ProductInventory.BLL.DTOs;
using ProductInventory.BLL.ViewModels;
using ProductInventory.DAL.Enums;

namespace ProductInventory.BLL.Interfaces;

/// <summary>
/// Business logic contract for product operations.
/// </summary>
public interface IProductService
{
    Task<ProductListViewModel> GetListAsync(string? searchTerm, ProductCategory? category, int pageNumber);

    Task<ProductViewModel?> GetByIdAsync(int id);

    Task<ServiceResult> CreateAsync(CreateProductViewModel model);

    Task<UpdateProductViewModel?> GetForEditAsync(int id);

    Task<ServiceResult> UpdateAsync(UpdateProductViewModel model);

    /// <summary>Soft delete: sets IsActive = false and preserves record in database.</summary>
    Task<ServiceResult> DeleteAsync(int id);

    Task<IReadOnlyList<ProductViewModel>> GetLowStockAsync();

    Task<RestockProductViewModel?> GetForRestockAsync(int id);

    Task<ServiceResult> RestockAsync(RestockProductViewModel model);

    /// <summary>Checks whether the given SKU is available for client-side remote validation.</summary>
    Task<bool> IsSkuUniqueAsync(string sku, int? excludeId = null);
}
