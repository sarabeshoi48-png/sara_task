using System.ComponentModel.DataAnnotations;
using ProductInventory.BLL.DTOs;
using ProductInventory.BLL.Interfaces;
using ProductInventory.BLL.ViewModels;
using ProductInventory.DAL.Entities;
using ProductInventory.DAL.Enums;
using ProductInventory.DAL.Repositories;

namespace ProductInventory.BLL.Services;

/// <summary>
/// Business logic implementation for product operations.
/// </summary>
public class ProductService : IProductService
{
    public const int DefaultPageSize = 10;
    public const int LowStockThreshold = 5; // BR-11

    private readonly IProductRepository _productRepository;

    public ProductService(IProductRepository productRepository)
    {
        _productRepository = productRepository;
    }

    public async Task<ProductListViewModel> GetListAsync(string? searchTerm, ProductCategory? category, int pageNumber)
    {
        var term = string.IsNullOrWhiteSpace(searchTerm) ? null : searchTerm.Trim();
        var page = Math.Max(1, pageNumber);

        var pageData = await _productRepository.GetFilteredPagedAsync(term, category, page, DefaultPageSize);
        var totalPages = Math.Max(1, (int)Math.Ceiling(pageData.TotalCount / (double)DefaultPageSize));

        if (page > totalPages)
        {
            page = totalPages;
            pageData = await _productRepository.GetFilteredPagedAsync(term, category, page, DefaultPageSize);
        }

        return new ProductListViewModel
        {
            SearchTerm = term,
            SelectedCategory = category,
            PageNumber = page,
            PageSize = DefaultPageSize,
            TotalCount = pageData.TotalCount,
            TotalPages = totalPages,
            Products = pageData.Items.Select(MapToViewModel).ToList()
        };
    }

    public async Task<ProductViewModel?> GetByIdAsync(int id)
    {
        // BR-10: null means NotFound
        var product = await _productRepository.GetByIdAsync(id);
        return product is null ? null : MapToViewModel(product);
    }

    public async Task<ServiceResult> CreateAsync(CreateProductViewModel model)
    {
        ArgumentNullException.ThrowIfNull(model);

        // BR-01..BR-08: server-side check of the ViewModel rules
        var validationFailure = ValidateModel(model);
        if (validationFailure is not null)
        {
            return validationFailure;
        }

        // BR-02: SKU must be unique
        var normalizedSku = model.SKU.Trim();
        if (!await _productRepository.IsSkuUniqueAsync(normalizedSku))
        {
            return DuplicateSku(normalizedSku);
        }

        // BR-09: CreatedAt is left to the database default (GETDATE())
        var product = new Product { IsActive = true };
        ApplyFields(product, model);

        await _productRepository.AddAsync(product);
        return ServiceResult.Success();
    }

    public async Task<UpdateProductViewModel?> GetForEditAsync(int id)
    {
        var product = await _productRepository.GetByIdAsync(id);
        if (product is null)
        {
            return null;
        }

        return new UpdateProductViewModel
        {
            Id = product.Id,
            Name = product.Name,
            SKU = product.SKU,
            Description = product.Description,
            Price = product.Price,
            StockQuantity = product.StockQuantity,
            Category = product.Category,
            ExpiryDate = product.ExpiryDate
        };
    }

    public async Task<ServiceResult> UpdateAsync(UpdateProductViewModel model)
    {
        ArgumentNullException.ThrowIfNull(model);

        // BR-10: the product must exist
        var existing = await _productRepository.GetByIdAsync(model.Id);
        if (existing is null)
        {
            return ServiceResult.NotFound($"Product with Id {model.Id} was not found.");
        }

        // BR-01..BR-08: server-side check of the ViewModel rules
        var validationFailure = ValidateModel(model);
        if (validationFailure is not null)
        {
            return validationFailure;
        }

        // BR-02: SKU must be unique, excluding this product
        var normalizedSku = model.SKU.Trim();
        if (!await _productRepository.IsSkuUniqueAsync(normalizedSku, model.Id))
        {
            return DuplicateSku(normalizedSku);
        }

        ApplyFields(existing, model); // BR-09: CreatedAt and IsActive are preserved
        await _productRepository.UpdateAsync(existing);
        return ServiceResult.Success();
    }

    public async Task<ServiceResult> DeleteAsync(int id)
    {
        // BR-10: the product must exist
        var existing = await _productRepository.GetByIdAsync(id);
        if (existing is null)
        {
            return ServiceResult.NotFound($"Product with Id {id} was not found.");
        }

        existing.IsActive = false; // BR-13: soft delete keeps the row and hides it from lists
        await _productRepository.UpdateAsync(existing);
        return ServiceResult.Success();
    }

    public async Task<IReadOnlyList<ProductViewModel>> GetLowStockAsync()
    {
        var products = await _productRepository.GetLowStockAsync(LowStockThreshold);
        return products.Select(MapToViewModel).ToList();
    }

    public async Task<RestockProductViewModel?> GetForRestockAsync(int id)
    {
        var product = await _productRepository.GetByIdAsync(id);
        if (product is null)
        {
            return null;
        }

        return new RestockProductViewModel
        {
            ProductId = product.Id,
            ProductName = product.Name,
            CurrentStock = product.StockQuantity
        };
    }

    public async Task<ServiceResult> RestockAsync(RestockProductViewModel model)
    {
        ArgumentNullException.ThrowIfNull(model);

        // BR-10: the product must exist
        var existing = await _productRepository.GetByIdAsync(model.ProductId);
        if (existing is null)
        {
            return ServiceResult.NotFound($"Product with Id {model.ProductId} was not found.");
        }

        // BR-12: QuantityToAdd must be greater than 0 ([Range(1, int.MaxValue)] on the ViewModel)
        var validationFailure = ValidateModel(model);
        if (validationFailure is not null)
        {
            return validationFailure;
        }

        if ((long)existing.StockQuantity + model.QuantityToAdd > int.MaxValue)
        {
            return ServiceResult.Failure(
                "Resulting stock quantity is too large.",
                nameof(RestockProductViewModel.QuantityToAdd));
        }

        existing.StockQuantity += model.QuantityToAdd;
        await _productRepository.UpdateAsync(existing);
        return ServiceResult.Success();
    }

    public Task<bool> IsSkuUniqueAsync(string sku, int? excludeId = null)
    {
        if (string.IsNullOrWhiteSpace(sku))
        {
            return Task.FromResult(true);
        }

        return _productRepository.IsSkuUniqueAsync(sku.Trim(), excludeId);
    }

    private static void ApplyFields(Product product, CreateProductViewModel model)
    {
        product.Name = model.Name.Trim();
        product.SKU = model.SKU.Trim();
        product.Description = string.IsNullOrWhiteSpace(model.Description) ? null : model.Description.Trim();
        product.Price = model.Price;
        product.StockQuantity = model.StockQuantity;
        product.Category = model.Category!.Value;
        product.ExpiryDate = model.ExpiryDate?.Date;
    }

    private static ServiceResult DuplicateSku(string sku) =>
        ServiceResult.Failure($"A product with SKU '{sku}' already exists.", nameof(CreateProductViewModel.SKU));

    private static ProductViewModel MapToViewModel(Product product) => new()
    {
        Id = product.Id,
        Name = product.Name,
        SKU = product.SKU,
        Description = product.Description,
        Price = product.Price,
        StockQuantity = product.StockQuantity,
        Category = product.Category,
        IsActive = product.IsActive,
        CreatedAt = product.CreatedAt,
        ExpiryDate = product.ExpiryDate
    };

    private static ServiceResult? ValidateModel(object model)
    {
        var results = new List<ValidationResult>();
        var context = new ValidationContext(model);
        if (Validator.TryValidateObject(model, context, results, validateAllProperties: true))
        {
            return null;
        }

        var firstError = results[0];
        var fieldName = firstError.MemberNames.FirstOrDefault();
        return ServiceResult.Failure(firstError.ErrorMessage ?? "Invalid product data.", fieldName);
    }
}
