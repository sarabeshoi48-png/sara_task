namespace ProductInventory.BLL.Validation;

internal static class ClientValidationAttributeHelper
{
    internal static void MergeAttribute(IDictionary<string, string> attributes, string key, string value)
    {
        if (!attributes.ContainsKey(key))
        {
            attributes.Add(key, value);
        }
    }
}
