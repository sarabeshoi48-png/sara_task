using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace ProductInventory.BLL.Validation;

/// <summary>
/// Validates that a nullable <see cref="DateTime"/> is today or in the future.
/// BR-07
/// </summary>
[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false)]
public sealed class FutureOrTodayDateAttribute : ValidationAttribute, IClientModelValidator
{
    public FutureOrTodayDateAttribute()
        : base("Expiry date cannot be in the past.")
    {
    }

    public override bool IsValid(object? value)
    {
        if (value is null)
        {
            return true;
        }

        if (value is DateTime dateValue)
        {
            return dateValue.Date >= DateTime.Today;
        }

        return false;
    }

    public void AddValidation(ClientModelValidationContext context)
    {
        ArgumentNullException.ThrowIfNull(context);

        var errorMessage = FormatErrorMessage(context.ModelMetadata.GetDisplayName());
        ClientValidationAttributeHelper.MergeAttribute(context.Attributes, "data-val", "true");
        ClientValidationAttributeHelper.MergeAttribute(context.Attributes, "data-val-futureortodaydate", errorMessage);
    }
}
