using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using ProductInventory.DAL.Enums;

namespace ProductInventory.BLL.Validation;

/// <summary>
/// Requires an expiry date when the product category is Grocery.
/// BR-08
/// </summary>
[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false)]
public sealed class GroceryExpiryRequiredAttribute : ValidationAttribute, IClientModelValidator
{
    public string CategoryProperty { get; }

    public GroceryExpiryRequiredAttribute(string categoryProperty = "Category")
        : base("Expiry date is required when Category is Grocery.")
    {
        CategoryProperty = categoryProperty;
    }

    protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
    {
        var categoryProp = validationContext.ObjectType.GetProperty(CategoryProperty);
        if (categoryProp is null)
        {
            return new ValidationResult($"Unknown property: {CategoryProperty}");
        }

        var categoryValue = categoryProp.GetValue(validationContext.ObjectInstance);
        if (categoryValue is ProductCategory category && category == ProductCategory.Grocery)
        {
            var isMissing = value is null || (value is string s && string.IsNullOrWhiteSpace(s));
            if (isMissing)
            {
                var memberNames = validationContext.MemberName is { } memberName
                    ? new[] { memberName }
                    : null;

                return new ValidationResult(
                    FormatErrorMessage(validationContext.DisplayName),
                    memberNames);
            }
        }

        return ValidationResult.Success;
    }

    public void AddValidation(ClientModelValidationContext context)
    {
        ArgumentNullException.ThrowIfNull(context);

        var errorMessage = FormatErrorMessage(context.ModelMetadata.GetDisplayName());
        ClientValidationAttributeHelper.MergeAttribute(context.Attributes, "data-val", "true");
        ClientValidationAttributeHelper.MergeAttribute(context.Attributes, "data-val-groceryexpiryrequired", errorMessage);
        ClientValidationAttributeHelper.MergeAttribute(context.Attributes, "data-val-groceryexpiryrequired-categoryproperty", CategoryProperty);
        ClientValidationAttributeHelper.MergeAttribute(context.Attributes, "data-val-groceryexpiryrequired-targetvalue", nameof(ProductCategory.Grocery));
        ClientValidationAttributeHelper.MergeAttribute(context.Attributes, "data-val-groceryexpiryrequired-targetint", ((int)ProductCategory.Grocery).ToString());
    }
}
