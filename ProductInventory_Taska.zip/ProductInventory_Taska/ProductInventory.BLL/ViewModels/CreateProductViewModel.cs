using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using ProductInventory.DAL.Enums;
using ProductInventory.BLL.Validation;

namespace ProductInventory.BLL.ViewModels;

/// <summary>
/// Input ViewModel for creating a new product.
/// </summary>
public class CreateProductViewModel
{
    // BR-01
    [Required(ErrorMessage = "Product name is required.")]
    [StringLength(100, ErrorMessage = "Product name cannot exceed 100 characters.")]
    public string Name { get; set; } = string.Empty;

    // BR-02 (uniqueness is checked in ProductService)
    [Required(ErrorMessage = "SKU is required.")]
    [StringLength(20, ErrorMessage = "SKU cannot exceed 20 characters.")]
    [Remote(
        action: "VerifySku",
        controller: "Products",
        AdditionalFields = nameof(UpdateProductViewModel.Id),
        ErrorMessage = "A product with this SKU already exists.")]
    public string SKU { get; set; } = string.Empty;

    // BR-03
    [StringLength(500, ErrorMessage = "Description cannot exceed 500 characters.")]
    public string? Description { get; set; }

    // BR-04
    [Required(ErrorMessage = "Price is required.")]
    [Range(typeof(decimal), "0.01", "9999999999999999.99", ParseLimitsInInvariantCulture = true, ErrorMessage = "Price must be greater than 0.")]
    public decimal Price { get; set; }

    // BR-05
    [Required(ErrorMessage = "Stock quantity is required.")]
    [Range(0, int.MaxValue, ErrorMessage = "Stock quantity cannot be negative.")]
    [Display(Name = "Stock Quantity")]
    public int StockQuantity { get; set; }

    // BR-06
    [Required(ErrorMessage = "Category is required.")]
    [EnumDataType(typeof(ProductCategory), ErrorMessage = "Invalid product category.")]
    public ProductCategory? Category { get; set; }

    // BR-07 (FutureOrTodayDate) and BR-08 (GroceryExpiryRequired)
    [DataType(DataType.Date)]
    [Display(Name = "Expiry Date")]
    [GroceryExpiryRequired]
    [FutureOrTodayDate]
    public DateTime? ExpiryDate { get; set; }
}
