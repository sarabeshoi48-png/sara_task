using ProductInventory.DAL.Enums;

namespace ProductInventory.BLL.ViewModels;

/// <summary>
/// Product list with search, category filter, and pagination metadata.
/// </summary>
public class ProductListViewModel
{
    public string? SearchTerm { get; set; }

    public ProductCategory? SelectedCategory { get; set; }

    public int PageNumber { get; set; } = 1;

    public int PageSize { get; set; }

    public int TotalCount { get; set; }

    public int TotalPages { get; set; } = 1;

    public IReadOnlyList<ProductViewModel> Products { get; set; } = Array.Empty<ProductViewModel>();

    public IReadOnlyList<ProductCategory> Categories { get; } = Enum.GetValues<ProductCategory>();

    public bool HasPrevious => PageNumber > 1;

    public bool HasNext => PageNumber < TotalPages;
}
