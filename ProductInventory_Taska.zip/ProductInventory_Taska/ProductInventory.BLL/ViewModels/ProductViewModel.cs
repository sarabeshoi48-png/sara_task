using ProductInventory.DAL.Enums;

namespace ProductInventory.BLL.ViewModels;

/// <summary>
/// Read-only display ViewModel for product lists and details.
/// </summary>
public class ProductViewModel
{
    public int Id { get; set; }

    public string Name { get; set; } = string.Empty;

    public string SKU { get; set; } = string.Empty;

    public string? Description { get; set; }

    public decimal Price { get; set; }

    public int StockQuantity { get; set; }

    public ProductCategory Category { get; set; }

    public bool IsActive { get; set; }

    public DateTime CreatedAt { get; set; }

    public DateTime? ExpiryDate { get; set; }
}
