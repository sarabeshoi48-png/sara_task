using System.ComponentModel.DataAnnotations;

namespace ProductInventory.BLL.ViewModels;

/// <summary>
/// Input ViewModel for the Restock action.
/// </summary>
public class RestockProductViewModel
{
    public int ProductId { get; set; }

    public string? ProductName { get; set; }

    [Display(Name = "Current Stock")]
    public int CurrentStock { get; set; }

    // BR-12
    [Required(ErrorMessage = "Quantity to add is required.")]
    [Range(1, int.MaxValue, ErrorMessage = "Quantity to add must be greater than 0.")]
    [Display(Name = "Quantity To Add")]
    public int QuantityToAdd { get; set; }
}
