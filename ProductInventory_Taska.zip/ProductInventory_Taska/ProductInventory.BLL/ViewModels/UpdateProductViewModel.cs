namespace ProductInventory.BLL.ViewModels;

/// <summary>
/// Input ViewModel for editing an existing product. Inherits validation rules from <see cref="CreateProductViewModel"/>.
/// </summary>
public class UpdateProductViewModel : CreateProductViewModel
{
    public int Id { get; set; }
}
