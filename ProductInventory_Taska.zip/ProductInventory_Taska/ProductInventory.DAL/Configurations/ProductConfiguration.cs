using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ProductInventory.DAL.Entities;
using ProductInventory.DAL.Enums;

namespace ProductInventory.DAL.Configurations;

/// <summary>
/// Fluent API configuration for <see cref="Product"/>.
/// </summary>
public class ProductConfiguration : IEntityTypeConfiguration<Product>
{
    public void Configure(EntityTypeBuilder<Product> builder)
    {
        builder.ToTable("Products");

        builder.HasKey(p => p.Id);

        // BR-01
        builder.Property(p => p.Name)
            .IsRequired()
            .HasMaxLength(100);

        // BR-02
        builder.Property(p => p.SKU)
            .IsRequired()
            .HasMaxLength(20);

        builder.HasIndex(p => p.SKU)
            .IsUnique();

        // BR-03
        builder.Property(p => p.Description)
            .IsRequired(false)
            .HasMaxLength(500);

        // BR-04
        builder.Property(p => p.Price)
            .IsRequired()
            .HasPrecision(18, 2);

        builder.Property(p => p.StockQuantity)
            .IsRequired();

        // BR-06
        builder.Property(p => p.Category)
            .IsRequired()
            .HasConversion<string>();

        // BR-09: IsActive and CreatedAt defaults come from the database.
        // Keep sentinel aligned with C# default (true) so DB default applies on normal inserts.
        builder.Property(p => p.IsActive)
            .HasDefaultValue(true)
            .HasSentinel(true);

        builder.Property(p => p.CreatedAt)
            .HasDefaultValueSql("GETDATE()");

        // Seed data: 12 sample products (some below the BR-11 low-stock threshold)
        builder.HasData(
            new Product { Id = 1, Name = "Wireless Mouse", SKU = "ELC-0001", Description = "Ergonomic 2.4GHz wireless mouse", Price = 25.50m, StockQuantity = 18, Category = ProductCategory.Electronics, IsActive = true, CreatedAt = new DateTime(2026, 11, 17) },
            new Product { Id = 2, Name = "USB-C Charger 65W", SKU = "ELC-0002", Description = "Fast charger for laptops and phones", Price = 39.99m, StockQuantity = 4, Category = ProductCategory.Electronics, IsActive = true, CreatedAt = new DateTime(2026, 11, 17) },
            new Product { Id = 3, Name = "Bluetooth Headphones", SKU = "ELC-0003", Description = "Over-ear headphones with noise cancelling", Price = 89.00m, StockQuantity = 9, Category = ProductCategory.Electronics, IsActive = true, CreatedAt = new DateTime(2026, 11, 17) },
            new Product { Id = 4, Name = "Whole Milk 1L", SKU = "GRC-0001", Description = "Fresh full-cream milk", Price = 4.25m, StockQuantity = 30, Category = ProductCategory.Grocery, IsActive = true, CreatedAt = new DateTime(2026, 11, 17), ExpiryDate = new DateTime(2027, 1, 15) },
            new Product { Id = 5, Name = "Basmati Rice 5kg", SKU = "GRC-0002", Description = "Long-grain basmati rice", Price = 12.75m, StockQuantity = 2, Category = ProductCategory.Grocery, IsActive = true, CreatedAt = new DateTime(2026, 11, 17), ExpiryDate = new DateTime(2027, 10, 1) },
            new Product { Id = 6, Name = "Olive Oil 1L", SKU = "GRC-0003", Description = "Extra virgin olive oil", Price = 9.90m, StockQuantity = 0, Category = ProductCategory.Grocery, IsActive = true, CreatedAt = new DateTime(2026, 11, 17), ExpiryDate = new DateTime(2027, 12, 31) },
            new Product { Id = 7, Name = "Cotton T-Shirt", SKU = "CLT-0001", Description = "100% cotton, unisex", Price = 14.99m, StockQuantity = 40, Category = ProductCategory.Clothing, IsActive = true, CreatedAt = new DateTime(2026, 11, 17) },
            new Product { Id = 8, Name = "Denim Jeans", SKU = "CLT-0002", Description = "Slim-fit blue denim", Price = 44.50m, StockQuantity = 3, Category = ProductCategory.Clothing, IsActive = true, CreatedAt = new DateTime(2026, 11, 17) },
            new Product { Id = 9, Name = "A4 Notebook", SKU = "STN-0001", Description = "80 pages, ruled", Price = 3.50m, StockQuantity = 120, Category = ProductCategory.Stationery, IsActive = true, CreatedAt = new DateTime(2026, 11, 17) },
            new Product { Id = 10, Name = "Ballpoint Pens (10 pack)", SKU = "STN-0002", Description = "Blue ink, medium tip", Price = 5.25m, StockQuantity = 1, Category = ProductCategory.Stationery, IsActive = true, CreatedAt = new DateTime(2026, 11, 17) },
            new Product { Id = 11, Name = "Desk Organizer", SKU = "OTH-0001", Description = "Wooden desk organizer with 5 slots", Price = 18.00m, StockQuantity = 7, Category = ProductCategory.Other, IsActive = true, CreatedAt = new DateTime(2026, 11, 17) },
            new Product { Id = 12, Name = "Gift Card 100", SKU = "OTH-0002", Description = "Store gift card worth 100", Price = 100.00m, StockQuantity = 25, Category = ProductCategory.Other, IsActive = true, CreatedAt = new DateTime(2026, 11, 17) });
    }
}
