using Microsoft.EntityFrameworkCore;
using ProductInventory.DAL.Entities;
using ProductInventory.DAL.Configurations;

namespace ProductInventory.DAL.Context;

/// <summary>
/// Entity Framework Core database context for the product inventory system.
/// </summary>
public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
    }

    public DbSet<Product> Products => Set<Product>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.ApplyConfiguration(new ProductConfiguration());
    }
}
