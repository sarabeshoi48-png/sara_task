using ProductInventory.DAL.Enums;

namespace ProductInventory.DAL.Entities;

/// <summary>
/// Represents a store product in the inventory database.
/// Configured via Fluent API in ProductInventory.DAL.
/// </summary>
public class Product
{
    public int Id { get; set; }

    public string Name { get; set; } = string.Empty;

    public string SKU { get; set; } = string.Empty;

    public string? Description { get; set; }

    public decimal Price { get; set; }

    public int StockQuantity { get; set; }

    public ProductCategory Category { get; set; }

    public bool IsActive { get; set; } = true;

    public DateTime CreatedAt { get; set; }

    public DateTime? ExpiryDate { get; set; }
}
