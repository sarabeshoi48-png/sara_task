namespace ProductInventory.DAL.Enums;

/// <summary>
/// Supported product categories stored as strings in SQL Server.
/// </summary>
public enum ProductCategory
{
    Electronics,
    Grocery,
    Clothing,
    Stationery,
    Other
}
