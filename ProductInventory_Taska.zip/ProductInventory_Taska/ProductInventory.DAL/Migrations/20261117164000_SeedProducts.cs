using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace ProductInventory.DAL.Migrations
{
    /// <inheritdoc />
    public partial class SeedProducts : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "Id", "Category", "CreatedAt", "Description", "ExpiryDate", "IsActive", "Name", "Price", "SKU", "StockQuantity" },
                values: new object[,]
                {
                    { 1, "Electronics", new DateTime(2026, 11, 17, 0, 0, 0, 0, DateTimeKind.Unspecified), "Ergonomic 2.4GHz wireless mouse", null, true, "Wireless Mouse", 25.50m, "ELC-0001", 18 },
                    { 2, "Electronics", new DateTime(2026, 11, 17, 0, 0, 0, 0, DateTimeKind.Unspecified), "Fast charger for laptops and phones", null, true, "USB-C Charger 65W", 39.99m, "ELC-0002", 4 },
                    { 3, "Electronics", new DateTime(2026, 11, 17, 0, 0, 0, 0, DateTimeKind.Unspecified), "Over-ear headphones with noise cancelling", null, true, "Bluetooth Headphones", 89.00m, "ELC-0003", 9 },
                    { 4, "Grocery", new DateTime(2026, 11, 17, 0, 0, 0, 0, DateTimeKind.Unspecified), "Fresh full-cream milk", new DateTime(2027, 1, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), true, "Whole Milk 1L", 4.25m, "GRC-0001", 30 },
                    { 5, "Grocery", new DateTime(2026, 11, 17, 0, 0, 0, 0, DateTimeKind.Unspecified), "Long-grain basmati rice", new DateTime(2027, 10, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), true, "Basmati Rice 5kg", 12.75m, "GRC-0002", 2 },
                    { 6, "Grocery", new DateTime(2026, 11, 17, 0, 0, 0, 0, DateTimeKind.Unspecified), "Extra virgin olive oil", new DateTime(2027, 12, 31, 0, 0, 0, 0, DateTimeKind.Unspecified), true, "Olive Oil 1L", 9.90m, "GRC-0003", 0 },
                    { 7, "Clothing", new DateTime(2026, 11, 17, 0, 0, 0, 0, DateTimeKind.Unspecified), "100% cotton, unisex", null, true, "Cotton T-Shirt", 14.99m, "CLT-0001", 40 },
                    { 8, "Clothing", new DateTime(2026, 11, 17, 0, 0, 0, 0, DateTimeKind.Unspecified), "Slim-fit blue denim", null, true, "Denim Jeans", 44.50m, "CLT-0002", 3 },
                    { 9, "Stationery", new DateTime(2026, 11, 17, 0, 0, 0, 0, DateTimeKind.Unspecified), "80 pages, ruled", null, true, "A4 Notebook", 3.50m, "STN-0001", 120 },
                    { 10, "Stationery", new DateTime(2026, 11, 17, 0, 0, 0, 0, DateTimeKind.Unspecified), "Blue ink, medium tip", null, true, "Ballpoint Pens (10 pack)", 5.25m, "STN-0002", 1 },
                    { 11, "Other", new DateTime(2026, 11, 17, 0, 0, 0, 0, DateTimeKind.Unspecified), "Wooden desk organizer with 5 slots", null, true, "Desk Organizer", 18.00m, "OTH-0001", 7 },
                    { 12, "Other", new DateTime(2026, 11, 17, 0, 0, 0, 0, DateTimeKind.Unspecified), "Store gift card worth 100", null, true, "Gift Card 100", 100.00m, "OTH-0002", 25 }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "Id",
                keyValues: new object[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 });
        }
    }
}
