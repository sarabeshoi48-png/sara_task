using ProductInventory.DAL.Entities;
using ProductInventory.DAL.Enums;

namespace ProductInventory.DAL.Repositories;

/// <summary>
/// Product-specific repository contract (no generic repository).
/// Only active products (IsActive = true) are visible to queries.
/// </summary>
public interface IProductRepository
{
    /// <summary>Searches by Name/SKU, filters by Category, and pages the active products.</summary>
    Task<PageData<Product>> GetFilteredPagedAsync(
        string? searchTerm, ProductCategory? category, int pageNumber, int pageSize);

    /// <summary>Gets an active product by Id, or null when it does not exist.</summary>
    Task<Product?> GetByIdAsync(int id);

    /// <summary>Gets active products with StockQuantity below the threshold.</summary>
    Task<IReadOnlyList<Product>> GetLowStockAsync(int threshold);

    /// <summary>Checks SKU uniqueness across ALL products, including inactive ones.</summary>
    Task<bool> IsSkuUniqueAsync(string sku, int? excludeId = null);

    Task AddAsync(Product product);

    Task UpdateAsync(Product product);
}
