using Microsoft.EntityFrameworkCore;

namespace ProductInventory.DAL.Repositories;

/// <summary>
/// One page of query results plus the total number of matching rows.
/// </summary>
public sealed class PageData<T>
{
    public PageData(IReadOnlyList<T> items, int totalCount)
    {
        Items = items;
        TotalCount = totalCount;
    }

    public IReadOnlyList<T> Items { get; }

    public int TotalCount { get; }
}

public static class PageDataExtensions
{
    /// <summary>
    /// Counts the query, then applies Skip/Take. The query must already be filtered and ordered.
    /// </summary>
    public static async Task<PageData<T>> ToPageAsync<T>(this IQueryable<T> query, int pageNumber, int pageSize)
    {
        var totalCount = await query.CountAsync();
        var items = await query
            .Skip((pageNumber - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync();

        return new PageData<T>(items, totalCount);
    }
}
