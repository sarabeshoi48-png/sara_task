using Microsoft.EntityFrameworkCore;
using ProductInventory.DAL.Context;
using ProductInventory.DAL.Entities;
using ProductInventory.DAL.Enums;

namespace ProductInventory.DAL.Repositories;

/// <summary>
/// EF Core implementation of <see cref="IProductRepository"/>.
/// </summary>
public class ProductRepository : IProductRepository
{
    private readonly AppDbContext _context;

    public ProductRepository(AppDbContext context)
    {
        _context = context;
    }

    public Task<PageData<Product>> GetFilteredPagedAsync(
        string? searchTerm, ProductCategory? category, int pageNumber, int pageSize)
    {
        // BR-13: soft-deleted products are hidden from the list
        var query = _context.Products.AsNoTracking().Where(p => p.IsActive);

        if (!string.IsNullOrWhiteSpace(searchTerm))
        {
            var term = searchTerm.Trim();
            query = query.Where(p => p.Name.Contains(term) || p.SKU.Contains(term));
        }

        if (category.HasValue)
        {
            var selected = category.Value;
            query = query.Where(p => p.Category == selected);
        }

        return query
            .OrderBy(p => p.Id)
            .ToPageAsync(pageNumber, pageSize);
    }

    public async Task<Product?> GetByIdAsync(int id)
    {
        // BR-10: returns null when the Id does not exist; BR-13: inactive products count as missing
        return await _context.Products
            .AsNoTracking()
            .FirstOrDefaultAsync(p => p.Id == id && p.IsActive);
    }

    public async Task<IReadOnlyList<Product>> GetLowStockAsync(int threshold)
    {
        // BR-11: StockQuantity strictly below the threshold; BR-13: active products only
        return await _context.Products
            .AsNoTracking()
            .Where(p => p.IsActive && p.StockQuantity < threshold)
            .OrderBy(p => p.StockQuantity)
            .ThenBy(p => p.Id)
            .ToListAsync();
    }

    public async Task<bool> IsSkuUniqueAsync(string sku, int? excludeId = null)
    {
        // BR-02: checked against all rows (active and inactive) because the unique index covers all of them
        var normalizedSku = sku.Trim();
        return !await _context.Products
            .AsNoTracking()
            .AnyAsync(p => p.SKU == normalizedSku && (!excludeId.HasValue || p.Id != excludeId.Value));
    }

    public async Task AddAsync(Product product)
    {
        await _context.Products.AddAsync(product);
        await _context.SaveChangesAsync();
    }

    public async Task UpdateAsync(Product product)
    {
        _context.Products.Update(product);
        await _context.SaveChangesAsync();
    }
}
