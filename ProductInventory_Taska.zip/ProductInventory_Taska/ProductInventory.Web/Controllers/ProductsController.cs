using Microsoft.AspNetCore.Mvc;
using ProductInventory.BLL.Interfaces;
using ProductInventory.BLL.ViewModels;
using ProductInventory.DAL.Enums;

namespace ProductInventory.Web.Controllers;

public class ProductsController : Controller
{
    private readonly IProductService _productService;

    public ProductsController(IProductService productService)
    {
        _productService = productService;
    }

    [HttpGet]
    public async Task<IActionResult> Index(string? search, ProductCategory? category, int page = 1)
    {
        var model = await _productService.GetListAsync(search, category, page);
        return View(model);
    }

    [HttpGet]
    public async Task<IActionResult> Details(int id)
    {
        var product = await _productService.GetByIdAsync(id);
        if (product is null)
        {
            return NotFound();
        }

        return View(product);
    }

    [HttpGet]
    public IActionResult Create()
    {
        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(CreateProductViewModel model)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var result = await _productService.CreateAsync(model);
        if (!result.Succeeded)
        {
            ModelState.AddModelError(
                result.FieldName ?? string.Empty,
                result.ErrorMessage ?? "Unable to create product.");
            return View(model);
        }

        TempData["SuccessMessage"] = "Product created successfully.";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var model = await _productService.GetForEditAsync(id);
        if (model is null)
        {
            return NotFound();
        }

        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, UpdateProductViewModel model)
    {
        if (id != model.Id)
        {
            return NotFound();
        }

        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var result = await _productService.UpdateAsync(model);
        if (result.IsNotFound)
        {
            return NotFound();
        }

        if (!result.Succeeded)
        {
            ModelState.AddModelError(
                result.FieldName ?? string.Empty,
                result.ErrorMessage ?? "Unable to update product.");
            return View(model);
        }

        TempData["SuccessMessage"] = "Product updated successfully.";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public async Task<IActionResult> Delete(int id)
    {
        var product = await _productService.GetByIdAsync(id);
        if (product is null)
        {
            return NotFound();
        }

        return View(product);
    }

    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var result = await _productService.DeleteAsync(id);
        if (result.IsNotFound)
        {
            return NotFound();
        }

        TempData["SuccessMessage"] = "Product deleted successfully.";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public async Task<IActionResult> LowStock()
    {
        var products = await _productService.GetLowStockAsync();
        return View(products);
    }

    [HttpGet]
    public async Task<IActionResult> Restock(int id)
    {
        var model = await _productService.GetForRestockAsync(id);
        if (model is null)
        {
            return NotFound();
        }

        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Restock(RestockProductViewModel model)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var result = await _productService.RestockAsync(model);
        if (result.IsNotFound)
        {
            return NotFound();
        }

        if (!result.Succeeded)
        {
            ModelState.AddModelError(
                result.FieldName ?? string.Empty,
                result.ErrorMessage ?? "Unable to restock product.");
            return View(model);
        }

        TempData["SuccessMessage"] = "Product restocked successfully.";
        return RedirectToAction(nameof(Index));
    }

    /// <summary>
    /// ASP.NET Core Remote Validation endpoint for immediate duplicate SKU feedback.
    /// Server-side uniqueness validation in ProductService remains authoritative.
    /// </summary>
    [AcceptVerbs("GET", "POST")]
    public async Task<IActionResult> VerifySku(string? sku, int? id)
    {
        if (string.IsNullOrWhiteSpace(sku))
        {
            return Json(true);
        }

        var isAvailable = await _productService.IsSkuUniqueAsync(sku, id);
        return isAvailable
            ? Json(true)
            : Json($"A product with SKU '{sku.Trim()}' already exists.");
    }
}
