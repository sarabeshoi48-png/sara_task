(function ($) {
    if (!$.validator || !$.validator.unobtrusive) {
        return;
    }

    function parseLocalDate(value) {
        var match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value.trim());
        if (!match) {
            return null;
        }

        var year = parseInt(match[1], 10);
        var month = parseInt(match[2], 10) - 1;
        var day = parseInt(match[3], 10);
        var date = new Date(year, month, day);

        if (date.getFullYear() !== year || date.getMonth() !== month || date.getDate() !== day) {
            return null;
        }

        return date;
    }

    function resolveDependentField(element, dependentProperty) {
        var $form = $(element).closest("form");
        var elementName = element.name || "";
        var lastDot = elementName.lastIndexOf(".");
        var prefix = lastDot >= 0 ? elementName.substring(0, lastDot + 1) : "";
        var targetName = prefix + dependentProperty;

        return $form.find("[name='" + targetName.replace(/'/g, "\\'") + "']");
    }

    $.validator.addMethod("futureortodaydate", function (value, element) {
        if (this.optional(element) || !value) {
            return true;
        }

        var inputDate = parseLocalDate(value);
        if (!inputDate) {
            return false;
        }

        var now = new Date();
        var today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        return inputDate >= today;
    });

    $.validator.unobtrusive.adapters.addBool("futureortodaydate");

    $.validator.addMethod("groceryexpiryrequired", function (value, element, params) {
        var $category = resolveDependentField(element, params.categoryproperty);
        if ($category.length === 0) {
            return true;
        }

        var selected = ($category.val() || "").toString().trim();
        var isGrocery = selected === params.targetvalue || selected === params.targetint;

        if (!isGrocery) {
            return true;
        }

        return $.trim(value).length > 0;
    });

    $.validator.unobtrusive.adapters.add(
        "groceryexpiryrequired",
        ["categoryproperty", "targetvalue", "targetint"],
        function (options) {
            options.rules["groceryexpiryrequired"] = {
                categoryproperty: options.params.categoryproperty,
                targetvalue: options.params.targetvalue,
                targetint: options.params.targetint
            };
            options.messages["groceryexpiryrequired"] = options.message;
        }
    );

    $(function () {
        $("[data-val-groceryexpiryrequired]").each(function () {
            var expiryInput = this;
            var categoryProperty = $(expiryInput).attr("data-val-groceryexpiryrequired-categoryproperty");
            if (!categoryProperty) {
                return;
            }

            var $category = resolveDependentField(expiryInput, categoryProperty);
            $category.on("change", function () {
                var $form = $(expiryInput).closest("form");
                if ($form.data("validator")) {
                    $(expiryInput).valid();
                }
            });
        });
    });
})(jQuery);
