# Product Inventory System

## 1. Purpose of the Product Inventory System

The **Product Inventory System** is an ASP.NET Core MVC (`.NET 8`) web application for a small store to manage its product catalog and stock levels. It provides full **CRUD** operations (`Create`, `Read` list & details, `Update`, `Soft Delete`), **Search & Category Filtering**, **Low Stock Monitoring** (`StockQuantity < 5`), **Restocking**, and **Pagination** backed by **Entity Framework Core** and **SQL Server**.

---

## 2. Three-Layer (N-Tier) Architecture

The solution (`ProductInventory.sln`) is separated into three projects. Each layer uses only the layer below it:

```
ProductInventory.Web (PL) ──▶ ProductInventory.BLL ──▶ ProductInventory.DAL ──▶ SQL Server
         │                                                    ▲
         └──── (Program.cs only, to register DI) ─────────────┘
```

- **One direction only:** `ProductInventory.DAL` references no other project; `ProductInventory.BLL` references `ProductInventory.DAL`; `ProductInventory.Web` references `ProductInventory.BLL` (and `ProductInventory.DAL` only for DI registration in `Program.cs`).
- **Strict PL isolation:** Controllers and Razor Views talk to `IProductService` only—never to `AppDbContext` or `IProductRepository`. They may use the `ProductCategory` enum from the DAL.

---

## 3. Project Responsibilities

| Project | Responsibilities |
| :--- | :--- |
| **`ProductInventory.DAL`** | `Entities/Product`, `Enums/ProductCategory`, `Context/AppDbContext`, Fluent API configuration (`Configurations/ProductConfiguration`), migrations (`20261115235752_InitialCreate` + `AppDbContextModelSnapshot`), and `Repositories/` (`IProductRepository`, `ProductRepository`, `PageData` with `ToPageAsync`). |
| **`ProductInventory.BLL`** | `Interfaces/IProductService`, `Services/ProductService` (business rules, with the BR number written next to each rule), `DTOs/ServiceResult`, ViewModels (`ProductViewModel`, `CreateProductViewModel`, `UpdateProductViewModel`, `ProductListViewModel`, `RestockProductViewModel`), and `Validation/` attributes (`GroceryExpiryRequiredAttribute`, `FutureOrTodayDateAttribute`, `ClientValidationAttributeHelper`). |
| **`ProductInventory.Web` (PL)** | Controllers (`ProductsController`, `HomeController` for the error page), Razor Views (`Views/Products/*`, `Views/Shared/*`), static assets (`wwwroot/js/product-validation.js`, Bootstrap/jQuery libs), configuration (`appsettings.json`), and composition root (`Program.cs`). |

---

## 4. How the Repository Pattern Is Applied

- A dedicated interface `ProductInventory.DAL.Repositories.IProductRepository` defines product-specific data operations (`GetFilteredPagedAsync`, `GetByIdAsync`, `GetLowStockAsync`, `IsSkuUniqueAsync`, `AddAsync`, `UpdateAsync`) **without using a Generic Repository**.
- `ProductInventory.DAL.Repositories.ProductRepository` implements `IProductRepository` using `AppDbContext` (`AsNoTracking()` for reads, server-side SQL filtering via `IQueryable`, paging via `ToPageAsync` in `PageData.cs` (Count, then Skip/Take), and `SaveChangesAsync()` for persistence).
- All queries (filtering, search, sorting, paging) live in the repository. `ProductService` in the BLL depends only on the `IProductRepository` interface and never touches `AppDbContext`.

---

## 5. How Dependency Injection Works

All dependencies are wired in `ProductInventory.Web/Program.cs` (the composition root—the only file in `ProductInventory.Web` that references `ProductInventory.DAL`):

- **Database Context (`Scoped`):** `AddDbContext<AppDbContext>` reads `ConnectionStrings:DefaultConnection` from configuration and configures SQL Server with `.MigrationsAssembly(typeof(AppDbContext).Assembly.GetName().Name)` pointing to `ProductInventory.DAL`.
- **Repository (`Scoped`):** `builder.Services.AddScoped<IProductRepository, ProductRepository>();`
- **Service (`Scoped`):** `builder.Services.AddScoped<IProductService, ProductService>();`
- **MVC Controllers:** `ProductsController` receives `IProductService` via constructor injection. Scoped lifetimes ensure one `AppDbContext`, repository, and service instance are shared per HTTP request cleanly.

---

## 6. How EF Core & Fluent API Are Configured

Database mapping lives strictly in `ProductInventory.DAL/Configurations/ProductConfiguration.cs` (`IEntityTypeConfiguration<Product>`) and is applied in `AppDbContext.OnModelCreating`, keeping `Product` free of database annotations:

- **Table & Key:** Maps to `Products`, primary key `Id`.
- **`Name`:** Required, `MaxLength(100)`.
- **`SKU`:** Required, `MaxLength(20)`, with `HasIndex(p => p.SKU).IsUnique()` (`IX_Products_SKU`).
- **`Description`:** Optional (`IsRequired(false)`), `MaxLength(500)`.
- **`Price`:** Required, `HasPrecision(18, 2)`.
- **`StockQuantity`:** Required (`int`).
- **`Category`:** Required, stored as `string` in SQL Server via `.HasConversion<string>()`.
- **`IsActive`:** Database-side default `true` via `.HasDefaultValue(true).HasSentinel(true)`.
- **`CreatedAt`:** Database-side default current date/time via `.HasDefaultValueSql("GETDATE()")`.

---

## 7. How CRUD and Bonus Operations Work

Every operation follows the strict flow:  
`ProductsController` → `IProductService` → `ProductService` → `IProductRepository` → `ProductRepository` → `AppDbContext` → `SQL Server`

- **Create (`GET/POST Products/Create`):** Validates `CreateProductViewModel`, enforces trimmed `SKU` uniqueness via `IsSkuUniqueAsync`, maps to `Product` (`IsActive = true`, DB default `CreatedAt`), and inserts via `AddAsync`.
- **Read List, Search, Filter & Pagination (`GET Products/Index`):** Accepts `search`, `category`, and `page`. Queries only active rows (`IsActive == true`), filters by `Name` or `SKU` and `Category`, counts total matches (`CountAsync`), clamps `page` within `[1, TotalPages]`, and loads one page (`PageSize = 10`, ordered by `Id`) via `Skip`/`Take`.
- **Read Details (`GET Products/Details/{id}`):** Returns mapped `ProductViewModel` or `404 NotFound` when missing or soft-deleted.
- **Update (`GET/POST Products/Edit/{id}`):** Verifies `id == model.Id` and active record existence (`NotFound` if missing), checks `SKU` uniqueness excluding the current product (`excludeId`), updates editable fields while preserving `CreatedAt` and `IsActive`, and saves via `UpdateAsync`.
- **Soft Delete (`GET/POST Products/Delete/{id}`):** Sets `IsActive = false` via `UpdateAsync` instead of deleting the database row (`NotFound` if missing or already inactive). Inactive products stay hidden from list, search, details, edit, low-stock, and restock queries.
- **Low Stock (`GET Products/LowStock`):** Queries active products with `StockQuantity < 5`, ordered by `StockQuantity` ascending then `Id`.
- **Restock (`GET/POST Products/Restock/{id}`):** Separate endpoint/view that validates product existence (`NotFound` if missing), requires `QuantityToAdd > 0`, guards against integer overflow, and increments `StockQuantity`.

---

## 8. Validation Rules Enforcement (Client + Server + Database)

| Rule | Description | Client Enforcement | Server & Database Enforcement |
| :--- | :--- | :--- | :--- |
| **Name** | Required, max 100 chars | `[Required]`, `[StringLength(100)]` (`CreateProductViewModel`) | MVC `ModelState` + `ProductService.ValidateModel`; SQL `nvarchar(100) NOT NULL` |
| **SKU** | Required, max 20 chars, unique | `[Required]`, `[StringLength(20)]`, plus `[Remote("VerifySku", "Products", AdditionalFields = "Id")]` AJAX check | MVC + `ProductService` checks `IsSkuUniqueAsync` (`excludeId` on Edit); SQL unique index `IX_Products_SKU` |
| **Description** | Optional, max 500 chars | `[StringLength(500)]` | MVC + `ProductService`; SQL `nvarchar(500) NULL` |
| **Price** | Must be `> 0` | `[Required]`, `[Range(typeof(decimal), "0.01", ..., ParseLimitsInInvariantCulture = true)]` | MVC + `ProductService`; SQL `decimal(18,2)` |
| **StockQuantity** | Must be `>= 0` | `[Required]`, `[Range(0, int.MaxValue)]` | MVC + `ProductService` |
| **Category** | Valid `ProductCategory` | `<select asp-items="Html.GetEnumSelectList<ProductCategory>()">` | `[Required]`, `[EnumDataType(typeof(ProductCategory))]`; DB string conversion |
| **ExpiryDate** | Not in the past | `FutureOrTodayDateAttribute` (`IClientModelValidator`) + `futureortodaydate` adapter in `wwwroot/js/product-validation.js` | `FutureOrTodayDateAttribute.IsValid` checks `dateValue.Date >= DateTime.Today` |
| **Grocery Rule** | Required when `Category == Grocery` | `GroceryExpiryRequiredAttribute` (`IClientModelValidator`) + `groceryexpiryrequired` adapter | `GroceryExpiryRequiredAttribute.IsValid` enforces non-null value when `Category == ProductCategory.Grocery` |
| **Existence (`Id`)** | Must exist on Details/Edit/Delete/Restock | N/A | `ProductService` returns `null` / `ServiceResult.NotFound()`; controller returns HTTP `404 NotFound()` |
| **Restock Qty** | Added quantity `> 0` | `[Required]`, `[Range(1, int.MaxValue)]` + `min="1"` | `RestockProductViewModel` DataAnnotations + `ProductService.RestockAsync` overflow check |

---

## 9. How the Grocery ExpiryDate Business Rule Works

1. `CreateProductViewModel.ExpiryDate` (inherited by `UpdateProductViewModel`) is decorated with `[GroceryExpiryRequired]` (defined in `ProductInventory.BLL/Validation/GroceryExpiryRequiredAttribute.cs`).
2. **Server-side:** `GroceryExpiryRequiredAttribute.IsValid` inspects the sibling `Category` property via reflection (`validationContext.ObjectType.GetProperty(CategoryProperty)`). If `Category == ProductCategory.Grocery` and `ExpiryDate` is `null`/empty, it returns a `ValidationResult` targeted at `ExpiryDate`.
3. **Client-side:** `GroceryExpiryRequiredAttribute` implements `IClientModelValidator`, emitting `data-val-groceryexpiryrequired`, `data-val-groceryexpiryrequired-categoryproperty="Category"`, `data-val-groceryexpiryrequired-targetvalue="Grocery"`, and `data-val-groceryexpiryrequired-targetint="1"`.
4. `ProductInventory.Web/wwwroot/js/product-validation.js` registers the jQuery Unobtrusive adapter `groceryexpiryrequired` and binds a `change` listener to the `Category` dropdown so `ExpiryDate` re-validates immediately when switching categories in the form.

---

## 10. Database Migrations (Multi-Project Commands)

Migrations live in `ProductInventory.DAL/Migrations`, and `ProductInventory.Web` serves as the startup project holding `appsettings.json` and `Microsoft.EntityFrameworkCore.Design`.

```bash
# Check if model changes require a new migration
dotnet ef migrations has-pending-model-changes --project ProductInventory.DAL --startup-project ProductInventory.Web

# Create a new migration when schema changes occur
dotnet ef migrations add <MigrationName> --project ProductInventory.DAL --startup-project ProductInventory.Web

# Apply migrations to SQL Server
dotnet ef database update --project ProductInventory.DAL --startup-project ProductInventory.Web
```

---

## 11. Running the Application

The connection string is `ConnectionStrings:DefaultConnection` in `ProductInventory.Web/appsettings.json` (SQL Server LocalDB `(localdb)\MSSQLLocalDB`, database `ProductInventoryDb`, Windows authentication — no password stored).

```bash
# Apply existing migrations if initializing a new database
dotnet ef database update --project ProductInventory.DAL --startup-project ProductInventory.Web

# Restore and build
dotnet restore ProductInventory.sln
dotnet build ProductInventory.sln

# Run the ASP.NET Core MVC web app
dotnet run --project ProductInventory.Web
```
