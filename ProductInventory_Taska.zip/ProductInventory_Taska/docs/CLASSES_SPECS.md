# Classes Specs Document — Product Inventory System

- **المرجع الأساسي:** [SRS.md](./SRS.md) & [Product_Inventory_System_Assessment.pdf](../Product_Inventory_System_Assessment.pdf)
- **الحالة:** مسودة مواصفات الكلاسات (في انتظار المراجعة والموافقة قبل توليد `Entities` و`DbContext` وتفصيل طبقات `N-Tier`).

---

## 1. Domain Entity & Enum

### 1.1 `ProductCategory` (Enum)
- **المرحلة:** MVP
- **الغرض:** تحديد الفئات المسموح بها للمنتج.
- **القيم (`Members`):**
  - `Electronics`
  - `Grocery`
  - `Clothing`
  - `Stationery`
  - `Other`
- **العلاقات:** يُستخدم كنوع للخاصية `Category` في `Product` والـ ViewModels الخاصة به (لا يوجد جدول منفصل؛ يُخزن كـ `string` في SQL Server).
- **الـ Validation:** يجب أن تكون القيمة ضمن القيم المعرّفة في الـ Enum (`EnumDataType` / `Enum.IsDefined`).
- **الـ FR / BR المرتبطة:** `FR-01`..`FR-04`, `FR-07`, `BR-06`, `BR-08`.

---

### 1.2 `Product` (Entity Class)
- **المرحلة:** MVP
- **الغرض:** تمثيل جدول المنتجات في قاعدة البيانات وحالته الأساسية في النظام.
- **الخصائص بأنواعها (Properties):**

| Property | Type | Nullable | Default / DB Behavior |
| :--- | :--- | :--- | :--- |
| `Id` | `int` | No | Primary Key (Identity) |
| `Name` | `string` | No | — |
| `SKU` | `string` | No | Unique Index |
| `Description` | `string?` | Yes | `null` |
| `Price` | `decimal` | No | SQL `decimal(18,2)` |
| `StockQuantity` | `int` | No | — |
| `Category` | `ProductCategory` | No | يُخزن في DB كـ `string` |
| `IsActive` | `bool` | No | DB Default: `true` |
| `CreatedAt` | `DateTime` | No | DB Default: Current Date |
| `ExpiryDate` | `DateTime?` | Yes | `null` |

- **العلاقات (Relationships):**
  - يعتمد على `ProductCategory` enum.
  - لا توجد Navigation Properties أو Foreign Keys مع كيانات أخرى في الـ SRS الحالي (`Product` هو الكيان الوحيد).
- **الـ Validation (على مستوى الكيان / قاعدة البيانات):**
  - `Name`: Required، حد أقصى `100` حرف (`BR-01`).
  - `SKU`: Required، حد أقصى `20` حرف، فريد `Unique` (`BR-02`).
  - `Description`: Optional، حد أقصى `500` حرف (`BR-03`).
  - `Price`: `> 0`، دقة `(18,2)` (`BR-04`).
  - `StockQuantity`: `>= 0` (`BR-05`).
  - `Category`: قيمة صالحة من `ProductCategory` وتُخزن كـ `string` (`BR-06`).
  - `ExpiryDate`: لا يكون في الماضي (`BR-07`)، وإلزامي إذا كانت `Category == ProductCategory.Grocery` (`BR-08`).
  - `IsActive` و`CreatedAt`: قيم افتراضية من جهة قاعدة البيانات (`BR-09`).
- **الـ FR / BR المرتبطة:** `FR-01`..`FR-11`, `BR-01`..`BR-13`.

---

## 2. Data Access & EF Core Configuration Classes

### 2.1 `ProductConfiguration` (`IEntityTypeConfiguration<Product>`)
- **المرحلة:** MVP
- **الغرض:** فصل إعدادات EF Core Fluent API لكيان `Product` في ملف مستقل (`NFR-01`).
- **الخصائص بأنواعها:** لا يحتوي على Data Properties؛ يحتوي على دالة `Configure(EntityTypeBuilder<Product> builder)`.
- **العلاقات:** يهيئ كيان `Product` داخل `AppDbContext.OnModelCreating`.
- **الـ Validation / DB Constraints:**
  - `HasKey(p => p.Id)`
  - `Name`: `IsRequired()`, `HasMaxLength(100)` (`BR-01`)
  - `SKU`: `IsRequired()`, `HasMaxLength(20)` + `HasIndex(p => p.SKU).IsUnique()` (`BR-02`)
  - `Description`: `HasMaxLength(500)` (`BR-03`)
  - `Price`: `HasPrecision(18, 2)` (`BR-04`)
  - `Category`: `HasConversion<string>()` (`BR-06`)
  - `IsActive`: `HasDefaultValue(true)` (`BR-09`)
  - `CreatedAt`: `HasDefaultValueSql(...)` للتاريخ الحالي على مستوى SQL Server (`BR-09` — راجع Open Questions بخصوص `GETDATE()` vs `GETUTCDATE()`)
- **الـ FR / BR / NFR المرتبطة:** `NFR-01`, `BR-01`..`BR-04`, `BR-06`, `BR-09`.

---

### 2.2 `AppDbContext` (`DbContext`)
- **المرحلة:** MVP
- **الغرض:** تمثيل جلسة الاتصال بقاعدة بيانات SQL Server وإدارة التغييرات والـ Migrations.
- **الخصائص بأنواعها:**
  - `Products`: `DbSet<Product>`
- **العلاقات:**
  - يعتمد على `DbContextOptions<AppDbContext>` (يُسجّل عبر DI في `Program.cs`).
  - يطبّق `ProductConfiguration` في `OnModelCreating`.
  - يُحقن في `ProductRepository` فقط.
- **الـ Validation:** تطبيق قيود الـ Schema والـ Unique Index أثناء الحفظ في SQL Server.
- **الـ FR / BR / NFR المرتبطة:** `NFR-01`, `NFR-02`, `NFR-03`, `FR-01`..`FR-11`.

---

### 2.3 `IProductRepository` (Interface) & `ProductRepository` (Class)
- **المرحلة:** MVP (والدوال الخاصة بـ Search/Pagination/LowStock في Later)
- **الغرض:** عزل استعلامات EF Core الخاصة بـ `Product` دون استخدام Generic Repository (`NFR-02`).
- **الخصائص / الاعتماديات (`Fields`):**
  - `_context`: `AppDbContext` (يُحقن عبر Constructor DI في `ProductRepository`).
- **العمليات المخططة (`Methods`):**
  - **MVP:** `GetAllAsync()`, `GetByIdAsync(int id)`, `AddAsync(Product product)`, `UpdateAsync(Product product)`, `DeleteAsync(Product product)`, `IsSkuUniqueAsync(string sku, int? excludeId = null)`.
  - **Later:** `GetFilteredPagedAsync(...)` (`FR-07`, `FR-11`), `GetLowStockAsync(int threshold)` (`FR-08`).
- **العلاقات:** يعتمد على `AppDbContext` ويتعامل مع كيان `Product`. يُسجل في `Program.cs` (`NFR-02`).
- **الـ Validation:**
  - فحص تفرد `SKU` في قاعدة البيانات (`BR-02`) مع استثناء الـ `Id` الحالي عند التعديل.
  - إرجاع `null` عند عدم وجود `Id` لتمكين إرجاع `NotFound` (`BR-10`).
  - استبعاد المنتجات غير النشطة (`IsActive == false`) في القوائم عند تفعيل Soft Delete (`BR-13`).
- **الـ FR / BR / NFR المرتبطة:** `NFR-02`, `FR-01`..`FR-05`, `FR-07`..`FR-11`, `BR-02`, `BR-10`, `BR-13`.

---

## 3. Business Logic, Services & ViewModels
*(تم اعتماد طبقة `BLL` ضمن نظام `N-Tier` من بداية الـ MVP لتفصل الـ Controller عن `DbContext` و`IProductRepository` وتنفذ الـ ViewModels والتحقق المزدوج `FR-06`.)*

### 3.1 `IProductService` (Interface) & `ProductService` (Class)
- **المرحلة:** MVP (وتُضاف دوال Search/Pagination/LowStock/Restock في Later)
- **الغرض:** تنفيذ قواعد العمل والتحويل بين `Product` Entity والـ ViewModels، ومنع تواصل الـ Controller مباشرة مع `DbContext` أو Repository (`NFR-03`).
- **الخصائص / الاعتماديات (`Fields`):**
  - `_productRepository`: `IProductRepository` (يُحقن عبر Constructor DI).
- **العلاقات:** يستدعيه `ProductsController`، ويستدعي `IProductRepository`.
- **الـ Validation / Business Rules:**
  - التحقق من وجود المنتج قبل العرض/التعديل/الحذف/Restock (`BR-10`).
  - التحقق من عدم تكرار `SKU` وإرجاع خطأ واضح (`BR-02`).
  - التحقق من `Price > 0` (`BR-04`)، `StockQuantity >= 0` (`BR-05`)، `ExpiryDate` ليس في الماضي (`BR-07`)، وإلزامية `ExpiryDate` لـ `Grocery` (`BR-08`).
  - تطبيق منطق `Low Stock < 5` (`BR-11` — Later)، `Restock > 0` (`BR-12` — Later)، و`Soft Delete` (`BR-13` — Later).
- **الـ FR / BR / NFR المرتبطة:** `NFR-03`, `FR-01`..`FR-11`, `BR-01`..`BR-13`.

---

### 3.2 `ProductViewModel` (Display Model)
- **المرحلة:** MVP (ويُعاد استخدامه في Low Stock / Search / Pagination في Later)
- **الغرض:** عرض بيانات المنتج في الـ Views (`Index`, `Details`, `Delete`, `LowStock`).
- **الخصائص بأنواعها:**
  - `Id` (`int`)
  - `Name` (`string`)
  - `SKU` (`string`)
  - `Description` (`string?`)
  - `Price` (`decimal`)
  - `StockQuantity` (`int`)
  - `Category` (`ProductCategory`)
  - `IsActive` (`bool`)
  - `CreatedAt` (`DateTime`)
  - `ExpiryDate` (`DateTime?`)
- **العلاقات:** يُعبّأ من `Product` داخل `ProductService` (أو Layer التحويل).
- **الـ Validation:** للعرض فقط (Read-only).
- **الـ FR / BR المرتبطة:** `FR-01`, `FR-02`, `FR-05`, `FR-07`, `FR-08`, `FR-10`, `FR-11`, `BR-11`, `BR-13`.

---

### 3.3 `CreateProductViewModel`
- **المرحلة:** MVP
- **الغرض:** استقبال والتحقق من مدخلات إنشاء منتج جديد (`Create` View) على الـ Client والـ Server.
- **الخصائص بأنواعها:**
  - `Name` (`string`)
  - `SKU` (`string`)
  - `Description` (`string?`)
  - `Price` (`decimal`)
  - `StockQuantity` (`int`)
  - `Category` (`ProductCategory`)
  - `ExpiryDate` (`DateTime?`)
  *(لا يحتوي على `Id` أو `CreatedAt` أو `IsActive` لأنها تُدار تلقائيًا/افتراضيًا حسب `BR-09`)*
- **العلاقات:** يُمرّر من `ProductsController` إلى `IProductService` ثم يُحوّل إلى `Product`.
- **الـ Validation (Client-side & Server-side):**
  - `Name`: `[Required]`, `[StringLength(100)]` (`BR-01`)
  - `SKU`: `[Required]`, `[StringLength(20)]` + فحص تفرد في Server (`BR-02`)
  - `Description`: `[StringLength(500)]` (`BR-03`)
  - `Price`: `[Required]`, أكبر من صفر `> 0` (`BR-04`)
  - `StockQuantity`: `[Required]`, `[Range(0, int.MaxValue)]` (`BR-05`)
  - `Category`: `[Required]`, `[EnumDataType(typeof(ProductCategory))]` (`BR-06`)
  - `ExpiryDate`: تحقق مخصص — لا يكون في الماضي (`BR-07`) + إجباري إذا كانت `Category == Grocery` (`BR-08`)
- **الـ FR / BR المرتبطة:** `FR-03`, `FR-06`, `BR-01`..`BR-09`.

---

### 3.4 `UpdateProductViewModel`
- **المرحلة:** MVP
- **الغرض:** استقبال والتحقق من مدخلات تعديل منتج قائم (`Edit` View) على الـ Client والـ Server.
- **الخصائص بأنواعها:**
  - `Id` (`int`)
  - `Name` (`string`)
  - `SKU` (`string`)
  - `Description` (`string?`)
  - `Price` (`decimal`)
  - `StockQuantity` (`int`) *(راجع Open Questions حول بقائه قابل للتعديل عند وجود `Restock`)*
  - `Category` (`ProductCategory`)
  - `ExpiryDate` (`DateTime?`)
  *(لا يُعدّل `CreatedAt`؛ وبخصوص `IsActive` في التعديل راجع Open Questions)*
- **العلاقات:** يطابق سجل `Product` المستهدف عبر `Id`.
- **الـ Validation (Client-side & Server-side):**
  - نفس قيود `CreateProductViewModel` (`BR-01`..`BR-08`).
  - `Id`: مطلوب ويجب أن يطابق منتجًا موجودًا (`BR-10`).
  - `SKU`: فريد مع استثناء الـ `Id` الحالي (`BR-02`).
- **الـ FR / BR المرتبطة:** `FR-04`, `FR-06`, `BR-01`..`BR-08`, `BR-10`.

---

### 3.5 `RestockProductViewModel`
- **المرحلة:** Later
- **الغرض:** استقبال والتحقق من كمية إعادة التخزين المضافة لمنتج موجود (`FR-09`).
- **الخصائص بأنواعها:**
  - `ProductId` (`int`)
  - `ProductName` (`string?`) — للعرض في الواجهة
  - `CurrentStock` (`int`) — للعرض في الواجهة
  - `QuantityToAdd` (`int`)
- **العلاقات:** يرتبط بكيان `Product` عبر `ProductId`.
- **الـ Validation (Client-side & Server-side):**
  - `ProductId`: مطلوب وموجود في قاعدة البيانات (`BR-10`).
  - `QuantityToAdd`: `[Required]`, `[Range(1, int.MaxValue)]` (`quantity > 0` — `BR-12`).
- **الـ FR / BR المرتبطة:** `FR-09`, `FR-06`, `BR-10`, `BR-12`.

---

### 3.6 `ProductListViewModel` (Search, Filter & Pagination)
- **المرحلة:** Later
- **الغرض:** تغليف قائمة المنتجات المعروضة مع معايير البحث والتصفية ومعلومات تقسيم الصفحات (`FR-07`, `FR-11`).
- **الخصائص بأنواعها:**
  - `SearchTerm` (`string?`) — للبحث بالاسم أو `SKU`
  - `SelectedCategory` (`ProductCategory?`) — للتصفية حسب الفئة
  - `PageNumber` (`int`)
  - `PageSize` (`int`)
  - `TotalCount` (`int`)
  - `TotalPages` (`int`)
  - `Products` (`IEnumerable<ProductViewModel>`)
- **العلاقات:** يجمع قائمة من `ProductViewModel` ويُمرّر بين `ProductsController` و`Index` View.
- **الـ Validation:** `PageNumber >= 1`، `PageSize >= 1`، و`SelectedCategory` (إن وُجدت) من قيم `ProductCategory` (`BR-06`).
- **الـ FR / BR المرتبطة:** `FR-01`, `FR-07`, `FR-11`, `BR-06`, `BR-13`.

---

### 3.7 Custom Validation Component (`GroceryExpiryRequiredAttribute` / `FutureOrTodayDateAttribute`)
- **المرحلة:** MVP
- **الغرض:** تنفيذ قواعد التحقق الشرطية والزمنية على الـ Client-side (عبر `IClientModelValidator` + jQuery Unobtrusive Validation) والـ Server-side (`ValidationAttribute` / `IValidatableObject`) داخل `CreateProductViewModel` و`UpdateProductViewModel`.
- **الخصائص / المعاملات:** اسم خاصية الفئة المستهدفة (`Category`) والقيمة المشروطة (`ProductCategory.Grocery`).
- **العلاقات:** يُطبّق على `ExpiryDate` داخل `CreateProductViewModel` و`UpdateProductViewModel`.
- **الـ Validation:**
  - رفض `ExpiryDate` إذا كان في الماضي (`BR-07`).
  - إجبارية `ExpiryDate` إذا كانت `Category == Grocery` (`BR-08`).
- **الـ FR / BR المرتبطة:** `FR-03`, `FR-04`, `FR-06`, `BR-07`, `BR-08`.

---

## 4. Presentation Layer (MVC Controller)

### 4.1 `ProductsController` (`Controller`)
- **المرحلة:** MVP (Actions الـ CRUD الأساسية) + Later (Search/Filter, LowStock, Restock, Soft Delete, Pagination)
- **الغرض:** استقبال طلبات الـ HTTP من الـ **Store User**، التحقق المبدئي من الـ `ModelState`، وتوجيه التنفيذ إلى `IProductService` ثم إرجاع View أو `NotFound`.
- **الخصائص / الاعتماديات (`Fields`):**
  - `_productService`: `IProductService` (يُحقن عبر Constructor DI).
- **العلاقات:**
  - يتعامل مع `IProductService` والـ ViewModels فقط.
  - ممنوع تعامله المباشر مع `AppDbContext` أو `IProductRepository` (عند تطبيق `NFR-03`).
- **الـ Validation:**
  - فحص `ModelState.IsValid` عند الإرسال (`Create`, `Edit`, `Restock`).
  - عرض أخطاء Server-side (مثل تكرار `SKU`) داخل `ModelState`.
  - إرجاع `NotFound()` عند عدم وجود المنتج (`BR-10`).
- **الـ FR / BR / NFR المرتبطة:** `FR-01`..`FR-11`, `BR-01`..`BR-13`, `NFR-03`, `NFR-04`.

---

## 5. نقاط مفتوحة تؤثر مباشرة على الكلاسات (مرتبطة بـ `Open Questions` في SRS)
*(لم يتم التخمين فيها — يُرجى حسمها مع الموافقة قبل كتابة الكود)*

1. **توقيت N-Tier (`IProductService` والـ ViewModels):** *(تم الحسم — مُعتمدة من الـ MVP: `DAL → BLL → PL` + `Tests`؛ لا يزال يلزم تحديد شكل الطبقات: 3 Projects منفصلين أم Folders في مشروع واحد)*.
2. **حذف المنتج (`FR-05` vs `FR-10`):** هل `Delete` في `ProductsController` و`ProductRepository` هينفذ Hard Delete أم Soft Delete (`IsActive = false`) أم الاثنين؟
3. **إعادة التفعيل وتعديل `SKU` و`StockQuantity` في `UpdateProductViewModel`:** هل `SKU` قابل للتعديل؟ هل `StockQuantity` يظل قابل للتعديل مع وجود `Restock`؟ وهل يُسمح بإعادة تفعيل منتج (`IsActive`)؟
4. **مقارنة `ExpiryDate` و`CreatedAt`:** هل `ExpiryDate` يُقارن بـ `Date` فقط أم `DateTime` (محلي أم UTC)؟ وهل `Update` يسمح بتعديل سعر منتج منتهي الصلاحية سابقًا؟
5. **الـ `PageSize` الافتراضي في `ProductListViewModel`:** غير محدد في الـ SRS.
