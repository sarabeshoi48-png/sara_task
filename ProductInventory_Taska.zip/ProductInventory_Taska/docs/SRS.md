# Software Requirements Specification (SRS) — Product Inventory System

- **السياق:** مشروع تخرج (4 طلاب — المدة: 3 أسابيع)
- **المرجع الأساسي:** [Product_Inventory_System_Assessment.pdf](../Product_Inventory_System_Assessment.pdf)
- **التقنية الأساسية:** ASP.NET MVC + Entity Framework Core (SQL Server)

---

## 1. نظرة عامة (Overview)
نظام **Product Inventory System** هو تطبيق ويب لإدارة مخزون المنتجات لمتجر صغير (`a small store`) باستخدام **ASP.NET MVC** و**Entity Framework Core** مع **SQL Server**. يتيح النظام تنفيذ عمليات إدارة المنتجات الأساسية (**CRUD**) مع تطبيق قواعد العمل والتحقق من البيانات على مستوى الـ Client والـ Server، والالتزام بـ Repository Pattern وDependency Injection.

---

## 2. Actors
- **Store User (`المستخدم`)**: المستخدم الوحيد المذكور في ملف المتطلبات (`the user`)، وهو المسؤول عن إدارة المنتجات في المخزون (عرض، إضافة، تعديل، حذف، وأي ميزات إضافية في المراحل اللاحقة).

> *(ملاحظة: الملف المرجعي لا يذكر نظام تسجيل دخول أو أدوار متعددة مثل Admin/Staff — راجع قسم **Open Questions**.)*

---

## 3. Functional Requirements (FR)

| ID | المتطلب | الوصف | المرحلة |
| :--- | :--- | :--- | :--- |
| **FR-01** | **List Products** | عرض قائمة بكل المنتجات المسجلة مع خصائصها (`Id`, `Name`, `SKU`, `Description`, `Price`, `StockQuantity`, `Category`, `IsActive`, `CreatedAt`, `ExpiryDate`). | MVP |
| **FR-02** | **Get Product by ID** | جلب وعرض تفاصيل منتج محدد باستخدام `Id`، وإرجاع `NotFound` في حال عدم وجوده. | MVP |
| **FR-03** | **Create Product** | إضافة منتج جديد مع تطبيق قواعد التحقق وملء القيم الافتراضية (`IsActive`, `CreatedAt`). | MVP |
| **FR-04** | **Update Product** | تعديل بيانات منتج قائم بناءً على `Id` مع تطبيق قواعد التحقق، وإرجاع `NotFound` في حال عدم وجوده. | MVP |
| **FR-05** | **Delete Product** | إزالة منتج قائم بناءً على `Id`، وإرجاع `NotFound` في حال عدم وجوده. | MVP |
| **FR-06** | **Client & Server Validation** | تطبيق التحقق من صحة المدخلات في كل من المتصفح (Client-side) والخادم (Server-side) مع عرض رسائل خطأ واضحة (مثل تكرار `SKU`). | MVP |
| **FR-07** | **Search & Filter** | البحث عن المنتجات بالاسم (`Name`) أو كود المنتج (`SKU`)، والتصفية حسب الفئة (`Category`). | Later |
| **FR-08** | **Low Stock List** | عرض قائمة بالمنتجات التي تقل كميتها في المخزون عن 5 (`StockQuantity < 5`). | Later |
| **FR-09** | **Restock Action** | توفير Action/Endpoint منفصل لإضافة كمية (`quantity > 0`) إلى الـ `StockQuantity` الحالي لمنتج محدد. | Later |
| **FR-10** | **Soft Delete** | تعطيل المنتج بتعيين `IsActive = false` بدلاً من حذف الصف من قاعدة البيانات، مع إخفاء المنتجات غير النشطة من القائمة. | Later |
| **FR-11** | **Pagination** | تقسيم قائمة المنتجات إلى صفحات (`Pagination`). | Later |

---

## 4. Data Model (`Product` Entity)
وفقًا للقسمين `2.1` و`2.2` في الملف المرجعي، يُهيأ الكيان `Product` باستخدام **Fluent API** عبر `IEntityTypeConfiguration<Product>`:

| Property | Type | القيود وإعدادات قاعدة البيانات (EF Core / SQL Server) |
| :--- | :--- | :--- |
| `Id` | `int` | Primary Key |
| `Name` | `string` | Required، الحد الأقصى للطول `100` |
| `SKU` | `string` | Required، الحد الأقصى للطول `20`، `Unique Index` (مثال: `ELC-0001`) |
| `Description` | `string?` | Optional، الحد الأقصى للطول `500` |
| `Price` | `decimal` | Precision `(18,2)`، يجب أن يكون `> 0` |
| `StockQuantity` | `int` | عدد الوحدات في المخزون، لا يمكن أن يكون سالبًا (`>= 0`) |
| `Category` | `ProductCategory` (enum) | القيم: `Electronics`, `Grocery`, `Clothing`, `Stationery`, `Other` — يُخزّن في DB كـ `string` وليس `int` |
| `IsActive` | `bool` | Default: `true` (Database-side default value) |
| `CreatedAt` | `DateTime` | Default: التاريخ الحالي (Database-side default value) |
| `ExpiryDate` | `DateTime?` | Optional (إلزامي إذا كانت `Category == Grocery`)، لا يمكن أن يكون في الماضي |

---

## 5. Business Rules (BR)

| ID | القاعدة | المرحلة |
| :--- | :--- | :--- |
| **BR-01** | **الاسم (`Name`)**: حقل مطلوب (`Required`) وبحد أقصى `100` حرف. | MVP |
| **BR-02** | **كود المنتج (`SKU`)**: حقل مطلوب (`Required`)، بحد أقصى `20` حرف، ويجب أن يكون فريدًا (`Unique`) مع إرجاع رسالة خطأ واضحة إذا كان مسجلاً مسبقًا. | MVP |
| **BR-03** | **الوصف (`Description`)**: حقل اختياري وبحد أقصى `500` حرف. | MVP |
| **BR-04** | **السعر (`Price`)**: يجب أن يكون أكبر من صفر (`Price > 0`). | MVP |
| **BR-05** | **الكمية (`StockQuantity`)**: لا يمكن أن تكون سالبة (`StockQuantity >= 0`). | MVP |
| **BR-06** | **الفئة (`Category`)**: مقيدة بقيم `ProductCategory` enum (`Electronics`, `Grocery`, `Clothing`, `Stationery`, `Other`)، وتُخزّن كـ `string` في قاعدة البيانات. | MVP |
| **BR-07** | **تاريخ الصلاحية (`ExpiryDate`)**: لا يمكن أن يكون في الماضي. | MVP |
| **BR-08** | **قاعدة البقالة (`Grocery`)**: إذا كانت `Category` هي `Grocery`، يكون حقل `ExpiryDate` إجباريًا (`Required`) مع تطبيق `BR-07`. | MVP |
| **BR-09** | **القيم الافتراضية بقاعدة البيانات**: القيمة الافتراضية لـ `IsActive` هي `true`، ولـ `CreatedAt` هي التاريخ الحالي، وكلاهما مُعد من جهة قاعدة البيانات. | MVP |
| **BR-10** | **التحقق من وجود الـ `ID`**: أي عملية تعتمد على `Id` يجب أن تتحقق من وجود المنتج، وإلا يرجع النظام `NotFound`. | MVP |
| **BR-11** | **حد المخزون المنخفض**: يُعتبر المنتج منخفض المخزون عندما تكون `StockQuantity < 5`. | Later |
| **BR-12** | **شرط الـ Restock**: الكمية المضافة في إجراء Restock يجب أن تكون أكبر من صفر (`quantity > 0`). | Later |
| **BR-13** | **إخفاء المنتجات غير النشطة**: عند تطبيق Soft Delete، تُعيّن `IsActive = false` وتُخفى المنتجات غير النشطة من قائمة العرض. | Later |

---

## 6. Non-Functional Requirements (NFR)
*(مقصورة على ما ورد صراحة في الملف المرجعي)*

- **NFR-01 — التقنية وقاعدة البيانات**:
  - بناء التطبيق باستخدام **ASP.NET MVC** و**Entity Framework Core** مع **SQL Server**.
  - تهيئة الكيان باستخدام **Fluent API** في ملف منفصل (`IEntityTypeConfiguration<Product>`).
  - تطبيق **EF Core Migrations** على قاعدة البيانات.
- **NFR-02 — نمط التصميم والاعتماديات (Repository & DI)**:
  - تطبيق Repository Pattern عبر `IProductRepository` و`ProductRepository` (ممنوع استخدام Generic Repository: `no generic repository`).
  - تطبيق Dependency Injection وتسجيل جميع الاعتماديات في `Program.cs`.
- **NFR-03 — المعمارية الطبقية (`N-tier Architecture` — مُعتمدة من الـ MVP بقرار الفريق)**:
  - **DAL (Data Access Layer)**: `DbContext`, entity configuration, migrations, repository.
  - **BLL (Business Logic Layer)**: services, validations, business rules, ViewModels.
  - **PL (Presentation Layer)**: MVC controllers وviews (تتواصل مع BLL فقط ولا تصل مباشرة لـ `DbContext` أو Repository).
- **NFR-04 — جودة الكود والتحقق**:
  - الالتزام بمبادئ Clean Code ووضوح رسائل الأخطاء.
  - تطبيق التحقق المزدوج (Client-side + Server-side validation).
- **NFR-05 — متطلبات التسليم والتوثيق (Submission Requirements)**:
  - تسليم الكود المصدري مع تطبيق EF Core Migrations.
  - تسليم توثيق مختصر يوضح: تطبيق Repository وDI، آلية عمل عمليات CRUD، ومكان وطريقة تطبيق كل قاعدة تحقق (بما في ذلك قاعدة `Grocery`).

---

## 7. Out of Scope
*(غير مذكور في الملف المرجعي أو مستبعد صراحةً)*

1. **Generic Repository Pattern** (مستبعد بنص الملف).
2. **إدارة المستخدمين والصلاحيات** (Authentication, Login, Authorization, Roles).
3. **المبيعات والطلبات والفواتير والدفع** (Orders, POS, Cart, Invoices, Payments).
4. **الموردون وأوامر الشراء** (Suppliers, Purchase Orders).
5. **تعدد المتاجر أو المخازن** (النطاق متجر صغير واحد فقط).
6. **التقارير المتقدمة والـ Dashboards وتصدير الملفات** (PDF/Excel/Analytics).
7. **سجل التدقيق الكامل (Audit Trail)** — المتاح فقط `CreatedAt`.
8. **الإشعارات التلقائية** (Email/SMS/Push Alerts).
9. **تطبيق موبايل أو REST API عامة منفصلة** عن ASP.NET MVC.

---

## 8. تقسيم الفيتشرز: MVP vs. Later

### MVP (المرحلة الأولى — متطلبات Sections `1`, `2.1–2.3`, `3` + قرار الفريق `N-Tier`)
- تهيئة المشروع بنظام **N-Tier (`DAL` → `BLL` → `PL`)** + SQL Server + EF Core + Fluent API (`IEntityTypeConfiguration<Product>`) + Migrations.
- تطبيق `IProductRepository` / `ProductRepository` + `IProductService` / `ProductService` + تسجيل DI في `Program.cs`.
- عمليات CRUD كاملة (`FR-01`..`FR-05`).
- التحقق على Client وServer وكل قواعد العمل الأساسية (`FR-06`، `BR-01`..`BR-10`).
- التوثيق الأساسي المطلوب للتسليم (`NFR-05`).

### Later (المرحلة الثانية — ميزات Section `2.4 Bonus Features` المتبقية)
- **Search & Filter** (`FR-07`).
- **Low Stock List** (`FR-08`, `BR-11`).
- **Restock Action** (`FR-09`, `BR-12`).
- **Soft Delete** (`FR-10`, `BR-13`).
- **Pagination** (`FR-11`).

---

## 9. Open Questions (أسئلة مفتوحة تحتاج حسم قبل التنفيذ)

1. **نطاق مشروع التخرج مقابل ملف التقييم:**
   - الملف المرفق مكتوب كتقييم لمطوّري `.NET` المبتدئين لـ Entity واحدة (`Product`). هل مشروع التخرج سيكتفي بمحتوى الملف (`MVP = 2.1–2.3` و`Later = 2.4`)، أم توجد متطلبات إضافية من المشرف/الكلية (مثل Auth، مبيعات، موردين، تقارير) لم ترد في الملف؟
   - بالنظر لوجود 4 طلاب خلال 3 أسابيع: هل تفضلون ضم ميزات `2.4` كلها داخل الـ MVP أم إبقاءها كمرحلة `Later`؟
2. **قرار الـ N-tier Architecture:**
   - هل ستُطبّق طبقات `DAL / BLL / PL` من اليوم الأول (كـ 3 مشاريع Class Library/MVC منفصلة أم Folders داخل مشروع واحد) لتسهيل تقسيم العمل بين الـ 4 طلاب؟
3. **العلاقة والتعارض بين Hard Delete (`2.3`) وSoft Delete (`2.4`):**
   - عند تطبيق Soft Delete (`IsActive = false`)، هل يُلغى الـ Hard Delete تمامًا أم يظل موجودًا؟
   - عند طلب `Get by ID` أو `Update` لمنتج حالته `IsActive = false`، هل يرجع `NotFound` أم يُعرض كمعطّل؟
   - هل يوجد خيار لإعادة تفعيل منتج معطّل (`Reactivate`)؟
   - مع وجود `Unique Index` على `SKU`: إذا حُذف منتج بـ Soft Delete، هل يُسمح بإعادة استخدام نفس الـ `SKU` لمنتج جديد (Filtered Unique Index) أم يظل محجوزًا؟
4. **المستخدمون والصلاحيات:**
   - الملف يذكر `the user` فقط بدون Login. هل النظام سيعمل بدون تسجيل دخول، أم يحتاج Authentication وRoles لمناقشة مشروع التخرج؟
5. **تفاصيل الـ Validation والحالات الحدية:**
   - **`ExpiryDate` في الماضي**: هل المقارنة بالتاريخ فقط (`Date` بحيث تاريخ اليوم مسموح) أم بالوقت (`DateTime`)؟ وبالتوقيت المحلي أم `UTC`؟
   - **تعديل منتج منتهي الصلاحية (`Update`)**: إذا انتهت صلاحية منتج مسجل مسبقًا وأراد المستخدم تعديل سعره أو اسمه، هل يُرفض التعديل بسبب قاعدة `ExpiryDate cannot be in the past` أم تُطبق القاعدة فقط عند الإنشاء أو تغيير `ExpiryDate`؟
   - **تغيير الفئة (`Category`) و`ExpiryDate`**: هل يُسمح بإدخال `ExpiryDate` اختياريًا للفئات غير `Grocery`؟ وإذا تغيرت الفئة من `Grocery` إلى فئة أخرى، هل يُمسح `ExpiryDate` أم يظل محفوظًا؟
   - **تقاطع `Update` مع `Restock`**: عند تطبيق `Restock`، هل يبقى حقل `StockQuantity` قابلاً للتعديل في شاشة `Update` أم يصبح Read-only؟ وهل يُسمح بعمل `Restock` لمنتج غير نشط أو منتج `Grocery` منتهي الصلاحية؟
   - **صيغة وتعديل `SKU`**: هل `ELC-0001` مجرد مثال أم مطلوب Regex/Format معين؟ وهل التحقق من التفرد Case-sensitive أم Case-insensitive؟ وهل `SKU` قابل للتعديل في `Update`؟
   - **`CreatedAt`**: هل القيمة الافتراضية على SQL Server تستخدم `GETDATE()` أم `GETUTCDATE()`؟ وهل يظل الحقل غير قابل للتعديل في `Update`؟
6. **تفاصيل Low Stock وPagination والواجهة:**
   - **Low Stock (`StockQuantity < 5`)**: هل يشمل المنتجات التي كميتها `0`؟ وهل يستبعد المنتجات غير النشطة (`IsActive = false`)؟
   - **Pagination**: ما هو حجم الصفحة الافتراضي (`PageSize`) والترتيب الافتراضي للقائمة؟
   - **الواجهة والعملة**: ما العملة المعروضة للسعر (`Price`)؟ وهل `Restock` سيكون صفحة مستقلة، Modal، أم Endpoint؟
7. **البيئة التقنية والاختبارات والتسليم:**
   - ما إصدار `.NET` المستهدف (مثل .NET 8 LTS) وإعداد SQL Server المحلي للفريق (LocalDB / SQL Express / Docker)؟
   - الاختبارات: تم الحسم — لا توجد Automated Tests (الـ Assessment لا يطلبها)؛ الاختبار يدوي.
   - هل هناك متطلبات أداء، أمان، أو Deployment/Hosting محددة (غير مذكورة في الملف) لمشروع التخرج؟
