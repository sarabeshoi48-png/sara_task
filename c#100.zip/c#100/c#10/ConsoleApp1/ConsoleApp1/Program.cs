﻿using System;
using System.Collections.Generic;

namespace ConsoleApp1
{

    #region Employee
    public class Employee : IComparable<Employee>, ICloneable

    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Salary { get; set; }
        public Employee(int _id, string _name, double _salary)
        {
            Id = _id;
            Name = _name;
            Salary = _salary;
        }
        public override string ToString()
        {
            return $"Id is {Id}, Name is {Name}, Salary is {Salary}";
        }
        public virtual int CompareTo(Employee other)

        {
            return Salary.CompareTo(other.Salary);
        }
        public object Clone()
        {
            return new Employee(Id, Name, Salary);
        }

    }
    #endregion

    #region maneger
    public class Manager : Employee
    {
        public string Department { get; set; }
        public Manager(int id, string name, double salary, string department)
            : base(id, name, salary)
        {
            Department = department;
        }
        public override int CompareTo(Employee other)
        {
            return base.CompareTo(other);
        }
        public override string ToString()
        {
            return $"[Manager] ID: {Id}, Name: {Name}, Salary: {Salary:C}, Dept: {Department}";
        }
    }
    #endregion

    #region sort
    public static class SortingAlgorithm<T> where T : IComparable<T>
    {
        public static void Sort(T[] items)
        {
            if (items == null || items.Length <= 1) return;

            for (int i = 0; i < items.Length - 1; i++)
            {
                for (int j = 0; j < items.Length - 1 - i; j++)
                {
                    if (items[j].CompareTo(items[j + 1]) == 1)
                    {
                        Swap(ref items[j], ref items[j + 1]);
                    }
                }
            }
        }
        private static void Swap(ref T a, ref T b)
        {
            T temp = a;
            a = b;
            b = temp;
        }

        public static void GenericSwap<T>(ref T a, ref T b)
        {
            T temp = a;
            a = b;
            b = temp;
        }
        public static T GetDefault<T>()
        {
            return default(T);
        }
        public static TItem[] CloneArray<TItem>(TItem[] items) where TItem : ICloneable
        {
            if (items == null) return null;
            TItem[] cloned = new TItem[items.Length];
            for (int i = 0; i < items.Length; i++)
            {
                cloned[i] = (TItem)items[i].Clone();
            }
            return cloned;
        }
    }
    #endregion

    #region sorting two
    public static class SortingTwo<T>
    {
        public static void Sort(T[] items, Func<T, T, bool> compareFunc)
        {
            if (items == null || items.Length <= 1) return;

            for (int i = 0; i < items.Length - 1; i++)
            {
                for (int j = 0; j < items.Length - 1 - i; j++)
                {
                    if (compareFunc(items[j], items[j + 1]))
                    {
                        Swap(ref items[j], ref items[j + 1]);
                    }
                }
            }
        }
        private static void Swap(ref T a, ref T b)
        {
            T temp = a;
            a = b;
            b = temp;
        }

    }
    #endregion



    internal class Program
    {
        public static double Compute(double a, double b, Func<double, double, double> op)
        {
            return op(a, b);
        }

        public static List<string> FilterWithLambda(List<string> list, Func<string, bool> predicate)
        {
            List<string> filtered = new List<string>();
            foreach (var item in list)
            {
                if (predicate(item)) filtered.Add(item);
            }
            return filtered;
        }

        public static int Calculate(int a, int b, Func<int, int, int> operation)
        {
            return operation(a, b);
        }

        public static List<string> FilterStrings(List<string> list, Func<string, bool> condition)
        {
            if (list == null || condition == null) return new List<string>();

            List<string> result = new List<string>();
            foreach (var item in list)
            {
                if (condition(item))
                {
                    result.Add(item);
                }
            }
            return result;
        }

        public static List<int> FilterNumbers(List<int> numbers, Predicate<int> isEven)
        {
            if (numbers == null || isEven == null) return new List<int>();
            List<int> filteredList = new List<int>();
            foreach (var num in numbers)
            {
                if (isEven(num))
                {
                    filteredList.Add(num);
                }
            }
            return filteredList;
        }

        public static int CalculateSquare(int a, int b, Func<int, int, int> multiplyFunc)
        {
            return multiplyFunc(a, b);
        }
        public static void ExecuteActionOnList(List<string> items, Action<string> action)
        {
            if (items == null || action == null) return;

            foreach (var item in items)
            {
                action(item);
            }
        }

        public static List<string> TransformStrings(List<string> list, Func<string, string> transformer)
        {
            if (list == null || transformer == null) return new List<string>();

            List<string> result = new List<string>();
            foreach (var item in list)
            {
                result.Add(transformer(item));
            }
            return result;
        }

        public static int PerformOperation(int a, int b, Func<int, int, int> operation)
        {
            return operation(a, b);
        }

        public static List<R> MapList<T, R>(List<T> list, Func<T, R> transformer)
        {
            if (list == null || transformer == null) return new List<R>();

            List<R> result = new List<R>();
            foreach (var item in list)
            {
                result.Add(transformer(item));
            }
            return result;
        }

        static void Main(string[] args)
        {
            Employee[] employees = new Employee[]
            {
                new Employee(101,"Ali",4500),
                new Employee(102,"Sara",9000),
                new Employee(103,"Mona",3200)
            };
            SortingAlgorithm<Employee>.Sort(employees);
            foreach (var emp in employees)
            {
                Console.WriteLine(emp);
            }

            int[] numbers = { 5, 1, 8, 3, 2 };
            SortingTwo<int>.Sort(numbers, (x, y) => x < y);
            Console.WriteLine(string.Join(",", numbers));

            string[] names = { "Menna", "Ali", "Sara", "Abdelrahman" };
            SortingTwo<string>.Sort(names, (x, y) => x?.Length > y?.Length);
            Console.WriteLine(string.Join(",", names));

            Employee[] staff = new Employee[]
            {
                new Manager(201,"Mona", 12000,"IT"),
                new Employee(101,"Ali",4500),
                new Manager(202,"Khaled",8500,"HR"),
                new Employee(102,"Sara", 9000)
            };
            SortingAlgorithm<Employee>.Sort(staff);
            foreach (var member in staff)
            {
                Console.WriteLine(member);
            }

            Employee[] empArray = new Employee[]
            {
                new Employee(1,"Mahmoud", 5000),
                new Employee(2,"Ali", 7000),
                new Employee(3,"Mostafa", 4000)
            };
            Func<Employee, Employee, bool> compareByNameLength = (e1, e2) => e1?.Name?.Length > e2?.Name?.Length;
            SortingTwo<Employee>.Sort(empArray, compareByNameLength);
            foreach (var emp in empArray)
            {
                Console.WriteLine(emp);
            }

            int[] nums1 = { 9, 3, 7, 1, 5 };
            int[] nums2 = { 9, 3, 7, 1, 5 };
            SortingTwo<int>.Sort(nums1, delegate (int x, int y)
            {
                return x > y;
            });
            SortingTwo<int>.Sort(nums2, (x, y) => x > y);
            Console.WriteLine(string.Join(", ", nums1));
            Console.WriteLine(string.Join(", ", nums2));

            int[] numberss = { 10, 20, 30, 40 };
            SortingAlgorithm<int>.GenericSwap(ref numberss[0], ref numberss[1]);
            Console.WriteLine($"After Swap:Index 0 = {numberss[0]},Index 1 = {numberss[1]}");


            Employee[] staffWithTies = new Employee[]
            {
                new Employee(1, "Sara", 5000),
                new Employee(2, "Ali", 7000),
                new Employee(3, "Ahmed", 5000)
            };
            SortingTwo<Employee>.Sort(staffWithTies, (e1, e2) => e1.Salary != e2.Salary
                ? e1.Salary > e2.Salary
                : e1.Name.CompareTo(e2.Name) > 0);
            foreach (var emp in staffWithTies)
            {
                Console.WriteLine(emp);
            }

            int defaultInt = SortingAlgorithm<int>.GetDefault<int>();
            Console.WriteLine($"Default Value Type (int): {defaultInt}");


            Employee[] originalStaff = new Employee[]
            {
                new Employee(10,"Ziad", 12000),
                new Employee(20, "Mona", 8000),
                new Employee(30,"Adel", 9500)
            };
            Employee[] sortedStaffCopy = SortingAlgorithm<Employee>.CloneArray(originalStaff);
            SortingAlgorithm<Employee>.Sort(sortedStaffCopy);
            foreach (var emp in originalStaff) Console.WriteLine(emp);
            foreach (var emp in sortedStaffCopy) Console.WriteLine(emp);

            List<string> names1 = new List<string> { "sara", "depi" };
            List<string> upper = TransformStrings(names1, s => s.ToUpper());
            Console.WriteLine(string.Join(", ", upper));

            int x = 12, y = 4;
            int sum = PerformOperation(x, y, (a, b) => a + b);
            int diff = PerformOperation(x, y, (a, b) => a - b);
            int prod = PerformOperation(x, y, (a, b) => a * b);
            int div = PerformOperation(x, y, (a, b) => b != 0 ? a / b : 0);
            Console.WriteLine($"Add: {sum} | Subtract: {diff} | Multiply: {prod} | Divide: {div}");

            List<int> numbers4 = new List<int> { 1, 2, 3, 4, 5 };
            List<string> stringRepresentations = MapList(numbers4, num => $"Number: {num}");
            Console.WriteLine(string.Join(", ", numbers4));
            Console.WriteLine(string.Join(" | ", stringRepresentations));


            Func<int, int, int> squareFunc = (a, b) => a * b;
            int number1 = 5;
            int result = CalculateSquare(number1, number1, squareFunc);
            Console.WriteLine(result);

            List<string> logs = new List<string> { "Task started", "Processing data", "Task completed" };
            Action<string> printConsole = message => Console.WriteLine($"[LOG]: {message}");
            ExecuteActionOnList(logs, printConsole);

            List<int> allNumbers = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            Predicate<int> checkEven = x => x % 2 == 0;
            List<int> evenNumbers = FilterNumbers(allNumbers, checkEven);
            Console.WriteLine(string.Join(", ", allNumbers));
            Console.WriteLine("Even Numbers:" + string.Join(", ", evenNumbers));

            List<string> words = new List<string> { "Sara", "DEPI", "DotNet", "Software", "Subnet" };
            List<string> startsWithS = FilterStrings(words, delegate (string str)
            {
                return str.StartsWith("S", StringComparison.OrdinalIgnoreCase);
            });
            List<string> containsNet = FilterStrings(words, s => s.Contains("Net", StringComparison.OrdinalIgnoreCase));
            Console.WriteLine(string.Join(", ", startsWithS));
            Console.WriteLine(string.Join(", ", containsNet));

            int x2 = 10;
            int y2 = 5;
            int addResult = Calculate(x2, y2, delegate (int a, int b) { return a + b; });
            Console.WriteLine($"Add: {addResult}");


            List<string> sampleWords = new List<string> { "csharp", "net", "code", "dev", "sara" };
            List<string> longWords = FilterWithLambda(sampleWords, s => s.Length > 3);
            List<string> wordsWithE = FilterWithLambda(sampleWords, s => s.Contains('e'));
            Console.WriteLine(string.Join(", ", longWords));
            Console.WriteLine(string.Join(", ", wordsWithE));


            double x3 = 10.0, y3 = 2.0;
            double divResult = Compute(x3, y3, (a, b) => b != 0 ? a / b : 0);
            double powResult = Compute(x3, y3, (a, b) => Math.Pow(a, b));
            Console.WriteLine($"Division: {divResult},Exponentiation: {powResult}");
        }


    }
}

//p1
//Ensures compile-time type checking to prevent runtime InvalidCastException.
//Code Reusability: Enables a single sorting method to be reused across any data type without writing redundant type-specific logic.

//p2
//Allows defining custom comparison rules inline with clean and self-explanatory syntax

//p3
//Provides flexible extensibility points to dynamically inject custom runtime rules

//p4
//Allows derived classes to either reuse the base comparison logic or override it to enforce specialized domain-specific comparison criteria without altering the sorting algorithm

//5
//Eliminates the need to explicitly declare custom delegate types,simplifying code architecture and syntax

//6
//Lambda expressions offer cleaner syntax using the => operator omitting explicit delegate keywords, types
//Both approaches generate identical IL code

//7
//Eliminates code duplication by handling any data type with a single method, avoiding boxing/unboxing overhead

//8
//Offers precise,multi-tiered ordering control in a single generic method without duplicating algorithm execution

//9
//Crucial in generic programming to safely assign or return baseline values for unconstrained type parameters (T) without causing compile-time errors

//10
//Enforces strict interface or class requirements on T catching invalid type usage at compile time rather than failing at runtime

//11
//Decouples the iteration logic from the transformation rules, promoting clean, modular, and reusable code

//12
//Separates the execution framework from specific mathematical formulas
//adhering strictly to the Open/Closed Principle

//13
//Transforms any input type T to any output type R safely at compile time, eliminating manual type casts

//14
//Eliminates the need to explicitly define custom delegate signatures

//15
//Explicitly signifies void-returning side-effect operations,improving code readability and developer intent

//16
//Encapsulates evaluation rules into explicit bool-returning criteria,making code expressive and self-documenting

//17
//Inline function definitions keep single-use,
//specialized logic right at the call site, keeping the global class scope clean

//18
//Enhances code locality by keeping short mathematical behaviors inline right where they are executed

//19
//Eliminates repetitive boilerplate syntax, making data filtering clean and readable in a single line

//20
//Allows writing complex mathematical formulas directly inline using concise syntax