﻿using System;
//using static System.Console;
namespace Csharp1
{
    internal class Program
    {
        class Point
        {
            public int X;
            public int Y;
        }
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!");
            //Console.ReadKey();


            #region problem1 
            ///*
            //This program defines two integer variables and 
            //calculates their sum
            //*/

            //int x = 10; // First  variable
            //int y = 20; // Second variable

            //// Calculate the sum of them
            //int sum = x + y;

            //// Output the result 
            //Console.WriteLine(sum);
            //Console.ReadKey();
            ////comment :ctrl + k + c
            ////comment :ctrl + k + u 
            #endregion

            #region problem2 

            ////value of x is string but DT is int 
            ////y used without declarecion 
            //int x = 10;
            //int y = 20;
            //Console.WriteLine(x + y);
            ////Runtime Error خطأ بيحصل  أثناء تنفيذ البرنامج وبيسبب توقفه
            //int a = 10;
            //int b = 0;
            //int result = a / b;
            //// Logical Error  خطأ في منطق لا يؤدي لتوقف البرنامج ولا يعطي خطأ ولكن ينتج عنه مخرجات خاطئة 
            //int num1 = 10;
            //int num2 = 20;
            //double average = num1 + num2 / 2; 
            #endregion

            #region problem3
            //string FullName = "Sara Beshoi";
            //int Age = 20;
            //decimal MonthlySalary = 5000.50m;
            //bool IsStudent = true;
            ////Standardization,Distinction,Readability, Clean Code 
            #endregion

            #region problem4
            //Point Point1 = new Point();
            //Point1.X = 10;
            //Point1.Y = 20;

            //Point Point2 = Point1;

            //Console.WriteLine(Point2.X);

            ////value type (int<string ....) in stack وبننسخ القيمه ولو عدلنا عليها اي حد كان واخد نفسها مش هيتاثر 
            ////ref type بيكون في اوبجيكت بتتخرن كقيمه في الستاك لكن بتشاور علي حد في الهيب  
            #endregion

            #region problem5
            //int X = 15;
            //int Y = 4;

            //Console.WriteLine(X + Y);
            //Console.WriteLine(X - Y);
            //Console.WriteLine(X * Y);
            //Console.WriteLine((double)X / Y);
            //Console.WriteLine(X % Y);

            ////2 ,,,,الرقم الاول هو الاصغر ف القسمه فالناتج الصحيح اللي طالع 0 وباقي القسمه هي 2  
            #endregion

            #region problem6
            //int Number = 14;

            //if (Number > 10 && Number % 2 == 0)
            //{
            //   Console.WriteLine("The number is greater than 10 and Even.");
            //}

            //else
            //{
            //  Console.WriteLine("The condition is not met.");
            //}
            //// && بيتعامل مع القيم نفسها ولو شرط اتحقق خلاص 
            ////& بيتعامل مع الانتيجار ك بيتات ولازم بيمشي عليهم كلهم حتي لو شرط اتحقق 
            #endregion

            #region problem7
            //Console.Write("Enter a double number: ");
            //double DoubleNum = Convert.ToDouble(Console.ReadLine());

            //int IntNum = (int)DoubleNum;
            //double ImplicitDouble = IntNum;

            ////because data loss <A double holds decimal values and occupies 8 bytes, while an int stores only whole numbers and occupies 4 bytes 
            #endregion


            #region problem8
            //Console.Write("Enter your age: ");
            //string InputAge = Console.ReadLine();

            //int Age = int.Parse(InputAge);

            //if (Age > 0)
            //{
            //    Console.WriteLine($"Valid Age: {Age}");
            //}
            //else
            //{
            //    Console.WriteLine("Age must be greater than 0.");
            //}
            ////(Exception) واعالجه احطه في try<catch او اعمله ب tryparse  
            #endregion

            #region promlem9
            //int X = 5;

            //Console.WriteLine(++X);
            //Console.WriteLine({X});
            //Console.WriteLine(X++);
            //Console.WriteLine({X});



            //int x = 5;
            //int y = ++x + x++;
            ////The value of x after execution is 7 
            ////x: Incremented ( by ++x and  by x++) a final value of 7
            ////y: Calculated as 6 + 6 resulting in 12 
            #endregion
















        }
    }
}
