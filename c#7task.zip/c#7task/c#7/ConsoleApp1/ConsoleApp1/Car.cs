﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Car
    {
        public int id { get; set; }
        public  string  brand  { get; set; }
        public decimal price { get; set; }

        public Car(int Id, string Brand, decimal Price)
        {
            id = Id;
            brand = Brand;
            price = Price;
        }

        public Car() : this(0, " ", 0.0m)
        {
        }

        public Car(int id) : this(id, " ", 0.0m)
        {
        }

        public Car(int id, string brand) : this(id, brand, 0.0m)
        {
        }

        public override string ToString()
        {
            return $"Id: {id}, Brand: {brand}, Price: {price:C}";
        }
    }
}
//p1
//To prevent callers from bypassing this required initialization,
//the compiler automatically stops generating the default parameterless constructor.
//If a parameterless constructor is still needed, it must be defined explicitly.

