﻿using ConsoleApp1.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.WebSockets;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Car2 : IMovable
    {
        public void Move()
        {
            Console.WriteLine("Car is moving on the road");
        }
    }
}
//p8
//Allows treating different concrete objects uniformly through a shared interface reference
