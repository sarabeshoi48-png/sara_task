﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ConsoleApp1
{
    internal class Child : Parent
    {
        public int z { get; set; }
        public Child(int X, int Y, int Z) : base(X, Y)
        {
            z = Z;
        }

        public new int ProductNew()
        {
            return x * y * z;
        }
        public override int ProductOverride()
        {
            return x * y * z;
        }

        public override string ToString()
        {
            return $"X: {x}, Y: {y}, Z: {z}";
        }
    }
}

//p3
//It guarantees that inherited members of the base class are properly initialized first before the derived class executes its own initialization logic
//It eliminates code duplication

//p5
//system.Object.ToString() returns the fully qualified class name(Namespace.ClassName).
//Overriding it provides a human-readable summary of the object's actual properties.
