﻿using ConsoleApp1.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Circle : IShape
    {
        public double Radius { get; set; }

        public Circle(double radius)
        {
            Radius = radius;
        }
        public double Area { 
            get
            {return  Math.PI* Radius *Radius; }
        }
        public void Draw()
        {
            Console.WriteLine($"Drawing Circle with Radius: {Radius}");
        }
    }
}
//p7
//Provides a single, common default implementation for features, preventing  code duplication across multiple classes
