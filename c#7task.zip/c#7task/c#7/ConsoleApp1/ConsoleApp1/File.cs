﻿using ConsoleApp1.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class File : IReadable, IWritable
    {
        public void Read()
        {
            Console.WriteLine("Reading data from file");
        }

        public void Write()
        {
            Console.WriteLine("Writing data to file");
        }
    }
}
//p9
//allows a class to implement multiple interfaces
