﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Parent
    {
        public int x { get; set; }
        public int y { get; set; }

        public Parent(int X, int Y)
        {
            x = X;
            y = Y;
        }
        public int ProductNew()
        {
            return x * y;
        }

        public virtual int ProductOverride()
        {
            return x * y;
        }
        public override string ToString()
        {
            return $"X: {x}, Y: {y} ";
        }

    }
}

//p4
//Static Binding(Early Binding / Compile-Time):
//The method call is bound to its implementation at compile-time based on the declared Reference Type.
//It delivers faster execution performance and is used with regular methods, method overloading, and method hiding (new keyword).
//Dynamic Binding(Late Binding / Runtime):
//The method call is resolved at runtime based on the actual Object Type stored in Heap memory.
//It provides polymorphic behavior and flexibility using virtual methods in the base class and override methods in the derived class via the Virtual Method Table (V-Table).
