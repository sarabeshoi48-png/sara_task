﻿using ConsoleApp1.interfaces;
using System;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Car c1 = new Car();
            Car c2 = new Car(101);
            Car c3 = new Car(102, "Toyota");
            Car c4 = new Car(103, "BMW", 50000m);

            Console.WriteLine(c1);
            Console.WriteLine(c2);
            Console.WriteLine(c3);
            Console.WriteLine(c4);

            Calculator calc = new Calculator();

            int TwoInt = calc.Sum(5, 10);
            int ThreeInt = calc.Sum(5, 10, 15);
            double TwoDouble = calc.Sum(5.5, 10.2);

            Console.WriteLine($"Sum of 2 ints: {TwoInt}");
            Console.WriteLine($"Sum of 3 ints: {ThreeInt}");
            Console.WriteLine($"Sum of 2 doubles: {TwoDouble}");

            Child ch = new Child(10, 20, 30);
            Console.WriteLine(ch);


            Child child = new Child(2, 3, 4);
            Parent parentRef = child;

            Console.WriteLine(parentRef.ProductNew());
            Console.WriteLine(child.ProductNew());
            Console.WriteLine(parentRef.ProductOverride());
            Console.WriteLine(child.ProductOverride());

            Parent p = new Parent(10, 20);
            Child c = new Child(10, 20, 30);
            Console.WriteLine(p);
            Console.WriteLine(c);

            IShape shape = new Rectangle(5.0, 4.0);
            shape.Draw();
            Console.WriteLine($"Calculated Area: {shape.Area}");

            IShape circle = new Circle(5.0);
            circle.Draw();
            circle.PrintDetails();

            IMovable movable = new Car2();
            movable.Move();

            File file = new File();
            file.Read();
            file.Write();

            Rectangle_2 rect = new Rectangle_2(5.0, 4.0);
            rect.Draw();
            Console.WriteLine($"Area: {rect.CalculateArea()}");
        }
    }
}
