﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Rectangle_2 : Shape
    {
        public double Width { get; set; }
        public double Height { get; set; }
        public Rectangle_2(double width, double height)
        {
            Width = width;
            Height = height;
        }

        public override void Draw()
        {
            Console.WriteLine($"Drawing Rectangle with Width: {Width} and Height: {Height}");
        }

        public override double CalculateArea()
        {
            return Width * Height;
        }

    }
}
//p10
//A virtual method has a default implementation in the base class, whereas an abstract method has no implementation and consists only of a signature
