﻿using ConsoleApp1.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Rectangle : IShape 
    {
        public double Width { get; set; }
        public double Height { get; set; }

        public Rectangle(double width, double height)
        {
            Width = width;
            Height = height;
        }
        public double Area
        {
            get
            {
                return Width * Height;
            }
        }

        public void Draw()
        {
            Console.WriteLine($"Drawing Rectangle [Width: {Width}, Height: {Height}, Area: {Area}]");
        }
    }
}
