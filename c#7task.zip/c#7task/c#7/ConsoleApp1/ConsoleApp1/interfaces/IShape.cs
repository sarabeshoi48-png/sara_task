﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.interfaces
{
    internal interface IShape
    {
        public double Area { get; }

        void Draw()
        {
        }
        public void PrintDetails()
        {
            Console.WriteLine($"[Shape Details]: Area = {Area}");
        }
    }
}
//p6
//An interface is purely an abstract contract that contains method and property signatures without any actual implementation code
