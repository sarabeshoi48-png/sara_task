﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal struct Account
    {
        private int _accountId;
        private string _accountHolder;
        private decimal _balance;

        public int AccountId
        {
            get { return _accountId; }
            set { _accountId = value; }
        }

        public string AccountHolder
        {
            get { return _accountHolder; }
            set{_accountHolder = value;}
        }

        public decimal Balance
        {
            get { return _balance; }
            set
            {
                if (value >= 0)
                    _balance = value;
            }
        }
        public Account(int accountId, string accountHolder, decimal initialBalance)
        {
            _accountId = accountId;
            _accountHolder = accountHolder;
            _balance = initialBalance;
        }

        public void DisplayAccountInfo()
        {
            Console.WriteLine($"ID: {AccountId}, Holder: {AccountHolder}, Balance: {Balance:C}");
        }
    }
}
//6
//While both enforce data protection using private fields and properties,
//encapsulation in structs operates under Value Type
//meaning property modifications on copied instances do not affect the original object unless passed by reference
//unlike classes which operate under Reference Type(shared memory address on heap).

//6
//Abstraction focuses on hiding internal implementation only view essential features to the user
//Abstraction operates at the design level to simplify interactions by hiding complexity, whereas Encapsulation operates at the implementation level by bundling data with methods and restricting direct access using private fields and properties