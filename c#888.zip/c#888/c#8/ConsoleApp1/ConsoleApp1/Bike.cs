﻿using ConsoleApp1.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Bike : IVehicle
    {
        public void StartEngine()
        {
            Console.WriteLine("Bike engine started");
        }

        public void StopEngine()
        {
            Console.WriteLine("Bike engine stopped.");
        }
    }
}
//p1
//it make broject depend on abstractions rather than concrete implementations 
//and The code does not depend on a specific class If we want to add a new class in the future we can and implement IVehicle on it