﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Book
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public Book() : this("Unknown Title", "Unknown Author")
        {
        }

        public Book(string title) : this(title, "Unknown Author")
        {
        }

        public Book(string title, string author)
        {
            Title = title;
            Author = author;
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"Book Title: '{Title}', Author: '{Author}'");
        }
    }
}
//8
//Constructor overloading improves class usability by providing multiple ways to initialize an object based on the available data.
//It enhances flexibility and simplifies object creation for developers without forcing them to provide unnecessary parameters
