﻿using ConsoleApp1.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Car : IVehicle
    {
        public void StartEngine()
        {
            Console.WriteLine("Car engine started ");
        }

        public void StopEngine()
        {
            Console.WriteLine("Car engine stopped.");
        }


    }
}
