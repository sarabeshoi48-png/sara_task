﻿using ConsoleApp1.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class CircleSeries : IShapeSeries
    {
        private int _currentRadius;

        public int CurrentShapeArea { get; set; }

        public CircleSeries()
        {
            ResetSeries();
        }

        public void GetNextArea()
        {
            _currentRadius++;
            CurrentShapeArea = (int)Math.Round(Math.PI * _currentRadius * _currentRadius);
        }

        public void ResetSeries()
        {
            _currentRadius = 1;
            CurrentShapeArea = (int)Math.Round(Math.PI * _currentRadius * _currentRadius);
        }

    }
}
