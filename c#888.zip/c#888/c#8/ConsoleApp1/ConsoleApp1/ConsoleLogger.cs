﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class ConsoleLogger : ILogger
    {
        public void Log(string message)
        {
            Console.WriteLine($"[Console Logger]: {message}");
        }
    }
}
//7
//Default interface implementations improve backward compatibility by allowing developers to add new members to existing interfaces
//without breaking the classes that already implement them. 
