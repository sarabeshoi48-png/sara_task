﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal interface ILogger
    {
        public void Log(string message)
        {
            Console.WriteLine($"[Default Logger]: {message}");
        }
    }
}
