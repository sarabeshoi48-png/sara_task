﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ConsoleApp1
{
    internal class Product : IComparable<Product>
    {
        public int id { get; set; }
        public decimal price { get; set; }

        public string name { get; set; }

        public Product(int Id, string Name, decimal Price)
        {
            id = Id;
            name = Name;
            price = Price;
        }

        public override string ToString()
        {
            return $"ID: {id}, Name: {name}, Price: {price:C}";
        }

        public int CompareTo(Product other)
        {

            if (other == null) return 1;

            return price.CompareTo(other.price);

        }
    }
}
//3
//Implementing IComparable provides a default sorting mechanism for custom objects,
//allowing standard Framework methods like Array.Sort() and List.Sort() to work
