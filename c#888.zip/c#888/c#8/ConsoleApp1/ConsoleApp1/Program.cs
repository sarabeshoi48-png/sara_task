﻿using ConsoleApp1.interfaces;
using System;

namespace ConsoleApp1
{
    internal class Program
    {
        public static void PrintTenShapes(IShapeSeries series)
        {
            series.ResetSeries();
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Shape {i + 1} Area: {series.CurrentShapeArea}");
                series.GetNextArea();
            }
            Console.WriteLine();


        }

        public static void SelectionSort(int[] numbers)
        {
            for (int i = 0; i < numbers.Length - 1; i++)
            {
                int minIndex = i;
                for (int j = i + 1; j < numbers.Length; j++)
                {
                    if (numbers[j] < numbers[minIndex])
                        minIndex = j;
                }
                int temp = numbers[i];
                numbers[i] = numbers[minIndex];
                numbers[minIndex] = temp;
            }
        }



        static void Main(string[] args)
        {

            IVehicle myCar = new Car();
            IVehicle myBike = new Bike();
            myBike.StartEngine();
            myCar.StartEngine();

            Shape rect = new Rectangle(5, 4);
            Shape circle = new Circle(3);
            rect.Display();
            circle.Display();

            Product[] products = new Product[]
            {
                new Product(1, "Laptop", 1200m),
                new Product(2, "Mouse", 25m),
                new Product(3, "Keyboard", 60m),
                new Product(4, "Monitor", 300m)
            };

            foreach (var p in products)
            {
                Console.WriteLine(p);
            }
            Array.Sort(products);
            foreach (var p in products)
            {
                Console.WriteLine(p);
            }

            Student originalStudent = new Student(1, "Sara", 95.5);
            Student shallowStudent = originalStudent;
            Student deepStudent = new Student(originalStudent);
            Console.WriteLine($"Original:{originalStudent}");
            Console.WriteLine($"Shallow:{shallowStudent}");
            Console.WriteLine($"Deep: {deepStudent}");
            originalStudent.Name = "Menna";
            originalStudent.Grade = 100;
            Console.WriteLine($"Original: {originalStudent}");
            Console.WriteLine($"Shallow: {shallowStudent}");
            Console.WriteLine($"Deep: {deepStudent}");

            Robot myRobot = new Robot();
            myRobot.Walk();
            IWalkable walkableRobot = myRobot;
            walkableRobot.Walk();

            Account myAccount = new Account(101, "Sara", 5000m);
            myAccount.DisplayAccountInfo();

            ILogger customLogger = new ConsoleLogger();
            customLogger.Log("This is a custom message.");

            Book book1 = new Book();
            Book book2 = new Book("Clean Code");
            Book book3 = new Book("Design Patterns", "Erich Gamma");
            book1.DisplayInfo();
            book2.DisplayInfo();
            book3.DisplayInfo();


            IShapeSeries squareSeries = new SquareSeries();
            PrintTenShapes(squareSeries);
            IShapeSeries circleSeries = new CircleSeries();
            PrintTenShapes(circleSeries);

            Shape2[] shapes = new Shape2[]
            {
                new Shape2("Rectangle", 45.5),
                new Shape2("Square", 16.0),
                new Shape2("Circle", 28.27),
                new Shape2("Triangle", 10.5),
                new Shape2("Square", 4.0)
            };
            foreach (var shape2 in shapes)
            {
                Console.WriteLine(shape2);
            }
            Array.Sort(shapes);
            foreach (var shape in shapes)
            {
                Console.WriteLine(shape);
            }

            GeometricShape rectt = new Rectangle2(10, 5);
            GeometricShape tri = new Triangle(6, 8);
            Console.WriteLine($"Rectangle - Area: {rectt.CalculateArea()}, Perimeter: {rectt.Perimeter}");
            Console.WriteLine($"Triangle  - Area: {tri.CalculateArea()}, Perimeter: {tri.Perimeter:F2}");


            int[] areas = { 49, 4, 100, 1, 25, 16 };
            Console.WriteLine("Before: " + string.Join(", ", areas));
            SelectionSort(areas);
            Console.WriteLine("After : " + string.Join(", ", areas));



            GeometricShape shape1 = ShapeFactory.CreateShape("Rectangle", 10, 5);
            GeometricShape shape22 = ShapeFactory.CreateShape("Triangle", 6, 8);
            Console.WriteLine($"Rectangle Area: {shape1.CalculateArea()}");
            Console.WriteLine($"Triangle Area: {shape22.CalculateArea()}");

        }
    }
}
