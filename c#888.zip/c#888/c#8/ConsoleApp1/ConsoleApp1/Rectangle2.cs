﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Rectangle2 : GeometricShape
    {
        public Rectangle2(double length, double width): base(length, width)
        {
        }
        public override double CalculateArea()
        {
            return Dimension1 * Dimension2;
        }
        public override double Perimeter => 2 * (Dimension1 + Dimension2);
    }
}
