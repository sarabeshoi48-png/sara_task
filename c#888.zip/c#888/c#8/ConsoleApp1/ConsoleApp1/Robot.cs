﻿using ConsoleApp1.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Robot : IWalkable
    {
        public void Walk()
        {
            Console.WriteLine("Robot is walking");

        }

        void IWalkable.Walk()
        {
            Console.WriteLine("Robot is walking via IWalkable interface ");
        }

    }
}
//5
//Explicit interface implementation resolves naming conflicts by qualifying the method name with the interface name ,
//This allows a class to implement multiple interfaces containing identical method signature or separate its own method from the interface method—without any collision.