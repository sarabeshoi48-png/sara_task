﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal abstract class Shape
    {
        public abstract double GetArea();
        public void Display()
        {
            Console.WriteLine($"Calculated Area = {GetArea()}");
        }
    }
}
//p2
//When you need to include variables, fields, or properties whereas interface include signiture and fully implemented mothod