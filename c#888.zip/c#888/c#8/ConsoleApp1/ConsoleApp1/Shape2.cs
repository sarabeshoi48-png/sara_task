﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Shape2 : IComparable<Shape2>
    {
        public string Name { get; set; }
        public double Area { get; set; }

        public Shape2 (string name, double area)
        {
            Name = name;
            Area = area;
        }
        public int CompareTo(Shape2 pass)
        {
            Shape2 other = (Shape2) pass;
            if (other == null) return 1;
            return Area.CompareTo(other.Area);
        }

        public override string ToString()
        {
            return $"Shape: {Name,-10} | Area: {Area}";
        }
    }
}

