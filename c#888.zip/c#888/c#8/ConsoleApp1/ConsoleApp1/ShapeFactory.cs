﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public static class ShapeFactory
    {
        public static GeometricShape CreateShape(string shapeType, double dim1, double dim2)
        {
            if (shapeType == "Rectangle")
            {
                return new Rectangle2(dim1, dim2);
            }
            else if (shapeType == "Triangle")
            {
                return new Triangle(dim1, dim2);
            }
            return null;
        }

    }
}
