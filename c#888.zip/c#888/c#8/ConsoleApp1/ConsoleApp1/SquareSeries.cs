﻿using ConsoleApp1.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class SquareSeries : IShapeSeries
    {

        private int _currentSide;

        public int CurrentShapeArea { get; set; }

        public SquareSeries()
        {
            ResetSeries();
        }

        public void GetNextArea()
        {
            _currentSide++;
            CurrentShapeArea = _currentSide * _currentSide;
        }

        public void ResetSeries()
        {
            _currentSide = 1;
            CurrentShapeArea = _currentSide * _currentSide; 
        }

    }
}
