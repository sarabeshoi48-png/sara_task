﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Grade { get; set; }
        public Student(int id, string name, double grade)
        {
            Id = id;
            Name = name;
            Grade = grade;
        }
        public Student(Student studentToCopy)
        {
            if (studentToCopy != null)
            {
                this.Id = studentToCopy.Id;
                this.Name = studentToCopy.Name;
                this.Grade = studentToCopy.Grade;
            }
        }
        public override string ToString()
        {
            return $"Id: {Id}, Name: {Name}, Grade: {Grade}";
        }
    }
}
//4
//The primary purpose of a copy constructor is to create a new object as an independent, deep copy of an existing object.
//It ensures that modifying the new object's state will not affect the original object in memory.
