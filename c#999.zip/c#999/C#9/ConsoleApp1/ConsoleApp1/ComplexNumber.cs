﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class ComplexNumber
    {
        public int Real { get; set; }
        public int Imag { get; set; }
        public override string ToString()
        {
            return $"{Real} + {Imag}i";
        }
        public static ComplexNumber operator *(ComplexNumber left, ComplexNumber right)
        {
            int lReal = left?.Real ?? 0;
            int lImag = left?.Imag ?? 0;
            int rReal = right?.Real ?? 0;
            int rImag = right?.Imag ?? 0;

            return new ComplexNumber()
            {
                Real = (lReal * rReal) - (lImag * rImag),
                Imag = (lReal * rImag) + (lImag * rReal)
            };
    }   }
}
