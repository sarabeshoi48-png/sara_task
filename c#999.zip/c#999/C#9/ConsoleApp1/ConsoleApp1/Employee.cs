﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public Employee(int id, string name)
        {
            Id = id;
            Name = name;
        }
        public override bool Equals(object obj)
        {
            Employee e = obj as Employee;
            if (e == null) return false;

            return this.Id == e.Id && this.Name == e.Name;
        }
        public override string ToString()
        {
            return $"ID: {Id}, Name: {Name}";
        }



    }
    class Helper2
    {
        public static int SearchArray<T>(T[] arr, T target)
        {
            if (arr == null) return -1;

            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i].Equals(target))
                    return i;
            }
            return -1;
        }

        public static void ReplaceArray<T>(T[] arr, T oldValue, T newValue)
        {
            if (arr == null) return;

            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] != null && arr[i].Equals(oldValue))
                {
                    arr[i] = newValue;
                }
            }
        }






    }

}
