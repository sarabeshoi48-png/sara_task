﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Employee2
    {

        public int Id { get; set; }
        public string Name { get; set; }
        public Department Dept { get; set; }

        public Employee2(int id, string name, Department dept)
        {
            Id = id;
            Name = name;
            Dept = dept;
        }
        public override bool Equals(object obj)
        {
            Employee2 e = obj as Employee2;
            if (e == null) return false;

            return this.Dept != null && this.Dept.Equals(e.Dept);
        }

        class Helper2
        {
            public static int SearchArray<T>(T[] arr, T target)
            {
                if (arr == null) return -1;

                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i] != null && arr[i].Equals(target))
                        return i;
                }
                return -1;
            }
        }
    }
}
