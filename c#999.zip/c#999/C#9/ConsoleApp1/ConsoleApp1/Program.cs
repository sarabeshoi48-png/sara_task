﻿using System;
using System.Collections.Generic;

namespace ConsoleApp1
{

    class ArrayHelper9
    {
        public static T FindMax<T>(T[] array) where T : IComparable<T>
        {
            if (array == null || array.Length == 0)
                throw new ArgumentException("Array is empty or null!");

            T max = array[0];
            for (int i = 1; i < array.Length; i++)
            {
                if (array[i].CompareTo(max) > 0)
                {
                    max = array[i];
                }
            }
            return max;
        }
    }

    class ArrayHelper22
    {
        public static void Swap<T>(T[] array, int index1, int index2)
        {
            if (array == null || index1 < 0 || index2 < 0 ||
                index1 >= array.Length || index2 >= array.Length)
                return;

            T temp = array[index1];
            array[index1] = array[index2];
            array[index2] = temp;
        }
    }

    class CustomStack<T>
    {
        private List<T> list = new List<T>();
        public void Push(T item) => list.Add(item);
        public T Pop()
        {
            T item = Peek();
            list.RemoveAt(list.Count - 1);
            return item;
        }
        public T Peek() => list[list.Count - 1];
    }

    class ArrayHelper
    {
        public static T[] ReverseArray<T>(T[] array)
        {
            if (array == null) return null;

            T[] reversed = new T[array.Length];
            for (int i = 0; i < array.Length; i++)
            {
                reversed[i] = array[array.Length - 1 - i];
            }
            return reversed;
        }
    }

    struct CircleStruct
    {
        public double Radius { get; set; }
        public string Color { get; set; } 
        public CircleStruct(double radius, string color)
        {
            Radius = radius;
            Color = color;
        }

        public static bool operator ==(CircleStruct a, CircleStruct b) => a.Equals(b);
        public static bool operator !=(CircleStruct a, CircleStruct b) => !a.Equals(b);
    }
    class CircleClass
    {
        public double Radius { get; set; }
        public string Color { get; set; }

        public CircleClass(double radius, string color)
        {
            Radius = radius;
            Color = color;
        }
    }

    class Helper
    {
        public static T Max<T>(T left, T right) where T : IComparable<T>
        {
            return left.CompareTo(right) > 0 ? left : right;
        }
    }

    enum Weekdays
    {
        Monday = 1, Tuesday, Wednesday, Thursday, Friday
    }

    enum Grades : short
    {
        F = 1, D, C, B, A
    }

    enum DefaultGender
    {
        Male, Female
    }
    enum ByteGender : byte
    {
        Male, Female
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            foreach (Weekdays day in Enum.GetValues(typeof(Weekdays)))
            {
                Console.WriteLine($" {day} {(int)day}");
            }

            foreach (Grades grade in Enum.GetValues<Grades>())
            {
                Console.WriteLine($"Name: {grade}, Value: {(short)grade}");
            }

            Person person1 = new Person("Sara", 20, "Software Engineering");
            Person person2 = new Person("Menna", 22, "Data Science");
            person1.PrintDetails();
            person2.PrintDetails();

            Child chiObj = new Child();
            chiObj.Salary = 5000;
            chiObj.DisplaySalary();

            double length = 5.0;
            double width = 3.0;
            double perimeter = Utility.CalculateRectanglePerimeter(length, width);
            Console.WriteLine($"Rectangle Perimeter: {perimeter}");

            ComplexNumber c1 = new ComplexNumber { Real = 3, Imag = 2 }; // 3 + 2i
            ComplexNumber c2 = new ComplexNumber { Real = 1, Imag = 4 }; // 1 + 4i
            ComplexNumber result = c1 * c2;
            Console.WriteLine($"Result: {result}");

            int defaultSize = sizeof(DefaultGender);
            int byteSize = sizeof(ByteGender);
            Console.WriteLine($"Default Gender Enum (int) Size: {defaultSize} bytes");
            Console.WriteLine($"Byte Gender Enum (byte) Size: {byteSize} bytes");

            double cTemp = 25.0;
            double fTemp = Utility.CelsiusToFahrenheit(cTemp);
            Console.WriteLine($"{cTemp}°C = {fTemp}°F");

            string input = "B";
            if (Enum.TryParse<Grades>(input, ignoreCase: true, out Grades result2))
            {
                Console.WriteLine($"Parsed successfully: {result2} = {(int)result2}");
            }
            else
            {
                Console.WriteLine($"Invalid Grade: '{input}' is not a valid enum value.");
            }


            Employee[] employees = {
                new Employee(1, "Sara"),
                new Employee(2, "Ahmed")
            };

            Employee target = new Employee(2, "Ahmed");
            int index = Helper2.SearchArray(employees, target);
            Console.WriteLine($"Found at Index: {index}");


            Console.WriteLine($"Max Double: {Helper.Max(15.5, 7.2)}");

            int[] numbers = { 1, 2, 3, 2, 4 };
            Helper2.ReplaceArray(numbers, 2, 99);
            Console.WriteLine("Numbers Array: " + string.Join(", ", numbers));

            Rectangle r1 = new Rectangle(10, 5);
            Rectangle r2 = new Rectangle(20, 15);
            Console.WriteLine($"Before Swap: r1 = {r1}, r2 = {r2}");
            Rectangle.Swap(ref r1, ref r2);
            Console.WriteLine($"After Swap:  r1 = {r1}, r2 = {r2}");


            Department hr = new Department(10, "HR");
            Department it = new Department(20, "IT");
            Employee2[] employeess = {
                new Employee2(1, "Sara", hr),
                new Employee2(2, "Ahmed", it)
            };

            Department searchDept = new Department(20, "IT");
            Employee2 searchTarget = new Employee2(0, "", searchDept);
            int index4 = Helper2.SearchArray(employeess, searchTarget);
            Console.WriteLine($"Employee in IT found at index: {index4}");


            CircleStruct s1 = new CircleStruct(5, "Red");
            CircleStruct s2 = new CircleStruct(5, "Red");
            Console.WriteLine($"StructEquals: {s1.Equals(s2)}");
            Console.WriteLine($"Struct == : {s1 == s2}");
            CircleClass c11 = new CircleClass(5, "Red");
            CircleClass c22 = new CircleClass(5, "Red");
            Console.WriteLine($"Class Equals: {c11.Equals(c22)}");
            Console.WriteLine($"Class ==: {c11 == c22}");

            //p2:1
            string[] names = { "Sara", "Mona", "Ahmed" };
            string[] reversedNames = ArrayHelper.ReverseArray(names);
            Console.WriteLine("Reversed Strings: " + string.Join(", ", reversedNames));

            //p2:2
            CustomStack<int> stack = new CustomStack<int>();
            stack.Push(10);
            stack.Push(20);
            Console.WriteLine(stack.Peek());

            //p2:3
            int[] numbers55 = { 10, 20, 30, 40 };
            ArrayHelper22.Swap(numbers55, 1, 3);
            Console.WriteLine(string.Join(", ",numbers55));

            //p2:4
            int[] numbers8 = { 5, 12, 3, 25, 8 };
            Console.WriteLine("Max Number:"+ ArrayHelper9.FindMax(numbers8)); 

        }


    }
}

//p1
//Explicitly assigning enum values ensures database consistency,
//prevents breaking changes when adding new members,
//and matches required external API or system values.

//p2
//If you assign a value that exceeds the underlying type's range, the C# compiler throws a Compile-time Error 
//preventing the code from compiling.

//p3
//It enables derived classes to override the property's get and set accessors to customize their behavior

//p4
//Because the sealed keyword locks the implementation to prevent further modification in derived classes

//p5
//Static members belong to the class itself and are shared across all instances a single copy exists in memory, accessed via the class name.
//object (instance) members belong to a specific instance, meaning each object holds its own independent copy of the data.

//p6
//No, because C# restricts overloading on essential operators (like =, ., &&, and ?:)
//to maintain language integrity and logical safety

//p7
//ou should change it to optimize memory usage for large collections, match smaller database column types 
// or minimize network payload size.

//p8
//Because static classes cannot be instantiated using new, making instance constructors irrelevant

//p9
//It prevents runtime exceptions on invalid inputs, improves performance,
//and directly converts string names and numbers into enum members safely.

//p10
//In classes, both default to reference comparison, so Equals is overridden for value comparison and == must be explicitly overloaded.
//In structs, Equals defaults to value comparison,
//while == is not supported by default and must be overloaded manually.

//p
//Overriding ToString() allows a custom class to return a readable representation of its internal data instead of the default type name (Namespace.ClassName).

//p11
//Yes, generics can be constrained using the where keyword to restrict the type
//arguments to specific classes, interfaces, or value/reference types.

//p12
//A generic method applies <T> only to a single method inside a class
//a generic class defines <T> for the entire class and requires specifying the type upon instantiatio.

//p13
//It avoids duplicating identical swapping code for different types, enforces compile-time type safety
//and simplifies maintenance by having a single reusable method

//p14
//It enables comparison based on property values (like Id or Name) rather than memory references,
//allowing search methods to correctly identify matching departments even when comparing separate object instances

//p15
//To avoid the significant performance overhead of reflection that a default field-by-field comparison would require,
//forcing developers to explicitly define efficient operator overloading when needed.


