﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal struct Rectangle
    {
        public double Length { get; set; }
        public double Width { get; set; }
        public Rectangle(double length, double width)
        {
            Length = length;
            Width = width;
        }

        public override string ToString()
        {
            return $"{Length} , {Width}";
        }

        public static void Swap(ref Rectangle rect1, ref Rectangle rect2)
        {
            Rectangle temp = rect1;
            rect1 = rect2;
            rect2 = temp;
        }
    }
}
