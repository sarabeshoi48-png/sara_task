﻿using day10_G01;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.WebSockets;
using System.Reflection.Metadata.Ecma335;
using System.Security.Cryptography;
using System.Threading;
using static day10_G01.ListGenerators;

namespace Linq_EFDay01
{
    internal class Program
    {

        static void Main()
        {
            //1,1
            var result01 = ProductList.Where(p => p.UnitsInStock == 0);
            var result01_Query = from p in ProductList
                                 where p.UnitsInStock == 0
                                 select p;

            foreach (var item in result01)
            {
                Console.WriteLine(item);
            }

            //1,2
            var result02 = ProductList.Where(p => p.UnitsInStock > 0 && p.UnitPrice > 3.00M);
            var result02_Query = from p in ProductList
                                 where p.UnitsInStock > 0 && p.UnitPrice > 3.00M
                                 select p;

            foreach (var item in result02)
            {
                Console.WriteLine(item);
            }

            //1,3
            string[] Arr = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };
            var result03 = Arr.Where((digit, index) => digit.Length < index);
            foreach (var item in result03)
            {
                Console.WriteLine(item);
            }

            //2,1
            var result011 = ProductList.FirstOrDefault(p => p.UnitsInStock == 0);
            var result011_Query = (from p in ProductList
                                   where p.UnitsInStock == 0
                                   select p).FirstOrDefault();

            Console.WriteLine(result011?.ProductName ?? "No out of stock products found");

            //2,2
            var result022 = ProductList.FirstOrDefault(p => p.UnitPrice > 1000);

            // Query Syntax (Hybrid)
            var result022_Query = (from p in ProductList
                                   where p.UnitPrice > 1000
                                   select p).FirstOrDefault();

            Console.WriteLine(result022?.ProductName ?? "No product found with price > 1000");

            //2,3
            int[] Arr2 = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            var result032 = Arr2.Where(n => n > 5).ElementAtOrDefault(1);
            var result032_Alt = Arr2.Where(n => n > 5).Skip(1).FirstOrDefault();
            Console.WriteLine(result03);

            //3.1
            int[] Arr01 = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            var result10 = Arr01.Count(n => n % 2 != 0);
            Console.WriteLine($"Number of odd numbers:{result10}");

            //3,2
            var result023 = CustomerList.Select(c => new
            {
                CustomerName = c.Name,
                OrderCount = c.Orders?.Length ?? 0
            });

            foreach (var item in result023)
            {
                Console.WriteLine($"{item.CustomerName}: {item.OrderCount} orders");
            }

            //3,3
            var result033 = ProductList.GroupBy(p => p.Category)
                           .Select(g => new
                           {
                               Category = g.Key,
                               ProductCount = g.Count()
                           });

            foreach (var item in result033)
            {
                Console.WriteLine($"{item.Category}: {item.ProductCount} products");
            }

            //3,4
            int[] Arr3 = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            var result04 = Arr3.Sum();
            Console.WriteLine($"Total sum of array:{result04}");

            //3,5
            string filePath = "dictionary_english.txt";
            if (!File.Exists(filePath))
            {
                File.WriteAllLines(filePath, new string[] {
                "apple", "banana", "cherry", "computer", "programming", "linq", "csharp"
            });
            }
            string[] words = File.ReadAllLines(filePath);
            var result05 = words.Sum(w => w.Length);
            Console.WriteLine($"Total characters in dictionary: {result05}");

            //3,6
            var result06 = ProductList.GroupBy(p => p.Category)
                           .Select(g => new
                           {
                               Category = g.Key,
                               TotalUnitsInStock = g.Sum(p => p.UnitsInStock)
                           });

            foreach (var item in result06)
            {
                Console.WriteLine($"{item.Category}: {item.TotalUnitsInStock}");
            }

            //3,7
            string[] words2 = File.ReadAllLines("dictionary_english.txt");
            var result07 = words2.Min(w => w.Length);
            Console.WriteLine($"Shortest word length:{result07}");

            //3,8
            var result08 = ProductList.GroupBy(p => p.Category)
                           .Select(g => new
                           {
                               Category = g.Key,
                               CheapestPrice = g.Min(p => p.UnitPrice)
                           });
            foreach (var item in result08)
            {
                Console.WriteLine($"{item.Category}: {item.CheapestPrice:C}");
            }

            //3,9
            var result09 = from p in ProductList
                           group p by p.Category into g
                           let minPrice = g.Min(p => p.UnitPrice)
                           select new
                           {
                               Category = g.Key,
                               CheapestProducts = g.Where(p => p.UnitPrice == minPrice)
                           };
            foreach (var group in result09)
            {
                Console.WriteLine($"Category: {group.Category}");
                foreach (var product in group.CheapestProducts)
                {
                    Console.WriteLine($"- {product.ProductName}: {product.UnitPrice:C}");
                }
            }

            //3,10
            string[] words3 = File.ReadAllLines("dictionary_english.txt");
            var result101 = words3.Max(w => w.Length);
            Console.WriteLine($"Longest word length: {result101}");

            //3,11
            var result11 = ProductList.GroupBy(p => p.Category)
                           .Select(g => new
                           {
                               Category = g.Key,
                               MostExpensivePrice = g.Max(p => p.UnitPrice)
                           });
            foreach (var item in result11)
            {
                Console.WriteLine($"{item.Category}: {item.MostExpensivePrice:C}");
            }

            //3,12
            var result12 = from p in ProductList
                           group p by p.Category into g
                           let maxPrice = g.Max(p => p.UnitPrice)
                           select new
                           {
                               Category = g.Key,
                               MostExpensiveProducts = g.Where(p => p.UnitPrice == maxPrice)
                           };
            foreach (var group in result12)
            {
                Console.WriteLine($"Category: {group.Category}");
                foreach (var product in group.MostExpensiveProducts)
                {
                    Console.WriteLine($" - {product.ProductName}: {product.UnitPrice:C}");
                }
            }

            //3,13
            string[] words4 = File.ReadAllLines("dictionary_english.txt");
            var result13 = words4.Average(w => w.Length);
            Console.WriteLine($"13. Average word length: {result13:F2}");

            //3,14
            var result14 = ProductList.GroupBy(p => p.Category)
                           .Select(g => new
                           {
                               Category = g.Key,
                               AveragePrice = g.Average(p => p.UnitPrice)
                           });
            foreach (var item in result14)
            {
                Console.WriteLine($"{item.Category}: {item.AveragePrice:C}");
            }



            //4,1
            var result012 = ProductList.OrderBy(p => p.ProductName);
            var result012_Query = from p in ProductList
                                  orderby p.ProductName
                                  select p;
            foreach (var product in result012)
            {
                Console.WriteLine(product.ProductName);
            }

            //4,2
            string[] Arr1 = { "aPPLE", "AbAcUs", "bRaNcH", "BlUeBeRrY", "ClOvEr", "cHeRry" };
            var result026 = Arr1.OrderBy(word => word, StringComparer.OrdinalIgnoreCase);
            foreach (var word in result026)
            {
                Console.WriteLine(word);
            }

            //4,3
            var result035 = ProductList.OrderByDescending(p => p.UnitsInStock);
            var result03_Query = from p in ProductList
                                 orderby p.UnitsInStock descending
                                 select p;

            foreach (var product in result035)
            {
                Console.WriteLine($"{product.ProductName}: {product.UnitsInStock}");
            }

            //4,4
            string[] Arr22 = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };
            var result046 = Arr22.OrderBy(digit => digit.Length)
                               .ThenBy(digit => digit);

            var result04_Query = from digit in Arr22
                                 orderby digit.Length, digit
                                 select digit;

            foreach (var digit in result046)
            {
                Console.WriteLine(digit);
            }


            //4,5
            string[] words9 = { "aPPLE", "AbAcUs", "bRaNcH", "BlUeBeRrY", "ClOvEr", "cHeRry" };
            var result059 = words9.OrderBy(w => w.Length)
                                .ThenBy(w => w, StringComparer.OrdinalIgnoreCase);

            foreach (var word in result059)
            {
                Console.WriteLine(word);
            }

            //4,6
            var result066 = ProductList.OrderBy(p => p.Category)
                                       .ThenByDescending(p => p.UnitPrice);

            var result06_Query = from p in ProductList
                                 orderby p.Category, p.UnitPrice descending
                                 select p;

            Console.WriteLine("Products sorted by category then unit price descending:");
            foreach (var product in result066)
            {
                Console.WriteLine($"{product.Category} - {product.ProductName}: {product.UnitPrice:C}");
            }

            //4,7
            string[] Arr38 = { "aPPLE", "AbAcUs", "bRaNcH", "BlUeBeRrY", "ClOvEr", "cHeRry" };
            var result077 = Arr38.OrderBy(w => w.Length)
                                .ThenByDescending(w => w, StringComparer.OrdinalIgnoreCase);

            foreach (var word in result077)
            {
                Console.WriteLine(word);
            }
            //4,8
            string[] Arr4 = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };

            var result080 = Arr4.Where(digit => digit.Length > 1 && digit[1] == 'i')
                               .Reverse()
                               .ToList();

            foreach (var digit in result080)
            {
                Console.WriteLine(digit);
            }

            //5,1
            var transResult01 = ProductList.Select(p => p.ProductName);
            foreach (var name in transResult01)
            {
                Console.WriteLine(name);
            }

            //5,2
            string[] wordsArr = { "aPPLE", "BlUeBeRrY", "cHeRry" };
            var transResult02 = wordsArr.Select(w => new { Upper = w.ToUpper(), Lower = w.ToLower() });
            foreach (var item in transResult02)
            {
                Console.WriteLine($"Upper: {item.Upper}, Lower: {item.Lower}");
            }

            //5,3
            var transResult03 = ProductList.Select(p => new
            {
                p.ProductID,
                p.ProductName,
                Price = p.UnitPrice
            });
            foreach (var item in transResult03)
            {
                Console.WriteLine($"ID: {item.ProductID}, Name: {item.ProductName}, Price: {item.Price}");
            }

            //5,4
            int[] ArrNums = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            var transResult04 = ArrNums.Select((val, idx) => new
            {
                Number = val,
                InPlace = (val == idx)
            });
            foreach (var item in transResult04)
            {
                Console.WriteLine($"{item.Number}: {item.InPlace}");
            }

            //5,5
            int[] numbersA = { 0, 2, 4, 5, 6, 8, 9 };
            int[] numbersB = { 1, 3, 5, 7, 8 };

            var transResult05 = from a in numbersA
                                from b in numbersB
                                where a < b
                                select new { A = a, B = b };

            foreach (var pair in transResult05)
            {
                Console.WriteLine($"{pair.A} is less than {pair.B}");
            }

            //5,6
            var transResult06 = CustomerList.SelectMany(c => c.Orders)
                                 .Where(o => o.Total < 500.00);

            foreach (var order in transResult06)
            {
                Console.WriteLine(order);
            }

            //5,7
            var transResult07 = CustomerList.SelectMany(c => c.Orders)
                                 .Where(o => o.OrderDate.Year >= 1998);

            foreach (var order in transResult07)
            {
                Console.WriteLine(order);
            }

            //6,1
            int[] ArrCount = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            var result018 = ArrCount.Count(n => n % 2 != 0);

            //6,2
            var result029 = CustomerList.Select(c => new
            {
                CustomerName = c.Name,
                OrderCount = c.Orders?.Length ?? 0
            });

            //6,3
            var result030 = ProductList.GroupBy(p => p.Category)
                           .Select(g => new
                           {
                               Category = g.Key,
                               ProductCount = g.Count()
                           });

            //6,4
            int[] ArrSum = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            var result040 = ArrSum.Sum();

            //6,5
            string filePath2 = "dictionary_english.txt";
            if (!File.Exists(filePath))
                File.WriteAllLines(filePath2, new string[] { "apple", "banana", "cherry", "computer", "programming", "linq" });

            string[] words05 = File.ReadAllLines(filePath);
            var result0500 = words05.Sum(w => w.Length);

            //6,6
            var result0600 = ProductList.GroupBy(p => p.Category)
                           .Select(g => new
                           {
                               Category = g.Key,
                               TotalUnitsInStock = g.Sum(p => p.UnitsInStock)
                           });

            //6,7
            string[] words07 = File.ReadAllLines("dictionary_english.txt");
            var result078 = words07.Min(w => w.Length);

            //6,8
            var result089 = ProductList.GroupBy(p => p.Category)
                           .Select(g => new
                           {
                               Category = g.Key,
                               CheapestPrice = g.Min(p => p.UnitPrice)
                           });


            //6,9
            var result099 = from p in ProductList
                           group p by p.Category into g
                           let minPrice = g.Min(p => p.UnitPrice)
                           select new
                           {
                               Category = g.Key,
                               CheapestProducts = g.Where(p => p.UnitPrice == minPrice)
                           };

            //6,10
            string[] words10 = File.ReadAllLines("dictionary_english.txt");
            var result100 = words10.Max(w => w.Length);

            //6,11
            var result111 = ProductList.GroupBy(p => p.Category)
                           .Select(g => new
                           {
                               Category = g.Key,
                               MostExpensivePrice = g.Max(p => p.UnitPrice)
                           });


            //6,12
            var result122 = from p in ProductList
                           group p by p.Category into g
                           let maxPrice = g.Max(p => p.UnitPrice)
                           select new
                           {
                               Category = g.Key,
                               MostExpensiveProducts = g.Where(p => p.UnitPrice == maxPrice)
                           };

            //6,13
            string[] words13 = File.ReadAllLines("dictionary_english.txt");
            var result133 = words13.Average(w => w.Length);

            //6,14
            var result142 = ProductList.GroupBy(p => p.Category)
                           .Select(g => new
                           {
                               Category = g.Key,
                               AveragePrice = g.Average(p => p.UnitPrice)
                           });


            //7,1
            var ordResult01 = ProductList.OrderBy(p => p.ProductName);
         foreach (var product in ordResult01)
            {
                Console.WriteLine(product.ProductName);
            }

            //7,2
            string[] Arr02 = { "aPPLE", "AbAcUs", "bRaNcH", "BlUeBeRrY", "ClOvEr", "cHeRry" };
            var ordResult02 = Arr02.OrderBy(w => w, StringComparer.OrdinalIgnoreCase);
            foreach (var word in ordResult02)
            {
                Console.WriteLine(word);
            }

            //7,3
            var ordResult03 = ProductList.OrderByDescending(p => p.UnitsInStock);
            foreach (var product in ordResult03)
            {
                Console.WriteLine($"{product.ProductName}: {product.UnitsInStock}");
            }

            //7,4
            string[] Arr04 = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };
            var ordResult04 = Arr04.OrderBy(d => d.Length)
                                   .ThenBy(d => d);

            foreach (var digit in ordResult04)
            {
                Console.WriteLine(digit);
            }

            //7,5
            string[] Arr05 = { "aPPLE", "AbAcUs", "bRaNcH", "BlUeBeRrY", "ClOvEr", "cHeRry" };
            var ordResult05 = Arr05.OrderBy(w => w.Length)
                                   .ThenBy(w => w, StringComparer.OrdinalIgnoreCase);

            foreach (var word in ordResult05)
            {
                Console.WriteLine(word);
            }

            //7,6
            var ordResult06 = ProductList.OrderBy(p => p.Category)
                              .ThenByDescending(p => p.UnitPrice);

            foreach (var product in ordResult06)
            {
                Console.WriteLine($"{product.Category} - {product.ProductName}: {product.UnitPrice:C}");
            }

            //7,7
            string[] Arr07 = { "aPPLE", "AbAcUs", "bRaNcH", "BlUeBeRrY", "ClOvEr", "cHeRry" };
            var ordResult07 = Arr07.OrderBy(w => w.Length)
                                   .ThenByDescending(w => w, StringComparer.OrdinalIgnoreCase);

            foreach (var word in ordResult07)
            {
                Console.WriteLine(word);
            }


            //8,1
            var partResult01 = CustomerList.Where(c => c.Country == "WA")
                               .SelectMany(c => c.Orders)
                               .Take(3);

            foreach (var order in partResult01)
            {
                Console.WriteLine(order);
            }

            //8,2
            var partResult02 = CustomerList.Where(c => c.Country == "WA")
                               .SelectMany(c => c.Orders)
                               .Skip(2);

            foreach (var order in partResult02)
            {
                Console.WriteLine(order);
            }

            //8,3
            int[] numbers03 = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            var partResult03 = numbers03.TakeWhile((val, idx) => val >= idx);
            foreach (var num in partResult03)
            {
                Console.WriteLine(num);
            }

            //8,4
            int[] numbers04 = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            var partResult04 = numbers04.SkipWhile(n => n % 3 != 0);
            foreach (var num in partResult04)
            {
                Console.WriteLine(num);
            }

            //8,5
            int[] numbers05 = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            var partResult05 = numbers05.SkipWhile((val, idx) => val >= idx);
            foreach (var num in partResult05)
            {
                Console.WriteLine(num);
            }

            //9,1
            var partResult011 = CustomerList.Where(c => c.Country == "WA")
                               .SelectMany(c => c.Orders)
                               .Take(3);

            foreach (var order in partResult011)
            {
                Console.WriteLine(order);
            }

            //9,2
            var partResult023 = CustomerList.Where(c => c.Country == "WA")
                               .SelectMany(c => c.Orders)
                               .Skip(2);

            foreach (var order in partResult023)
            {
                Console.WriteLine(order);
            }

            //9,3
            int[] numbers036 = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            var partResult033 = numbers036.TakeWhile((val, idx) => val >= idx);
            foreach (var num in partResult033)
            {
                Console.WriteLine(num);
            }

            //9,4
            int[] numbers045 = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            var partResult043 = numbers045.SkipWhile(n => n % 3 != 0);
            foreach (var num in partResult043)
            {
                Console.WriteLine(num);
            }

            //9,5
            int[] numbers051 = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            var partResult051 = numbers051.SkipWhile((val, idx) => val >= idx);
            foreach (var num in partResult051)
            {
                Console.WriteLine(num);
            }

            //10,1
            string[] words01 = File.ReadAllLines("dictionary_english.txt");
            var quantResult01 = words01.Any(w => w.Contains("ei"));
            Console.WriteLine($"Any word contains 'ei': {quantResult01}");

            //10,2
            var quantResult02 = ProductList.GroupBy(p => p.Category)
                               .Where(g => g.Any(p => p.UnitsInStock == 0));

            foreach (var group in quantResult02)
            {
                Console.WriteLine($"Category: {group.Key}");
                foreach (var p in group)
                {
                    Console.WriteLine($"  - {p.ProductName} (Stock: {p.UnitsInStock})");
                }
            }

            //10,3
            var quantResult03 = ProductList.GroupBy(p => p.Category)
                               .Where(g => g.All(p => p.UnitsInStock > 0));

            foreach (var group in quantResult03)
            {
                Console.WriteLine($"Category: {group.Key}");
                foreach (var p in group)
                {
                    Console.WriteLine($" - {p.ProductName} (Stock: {p.UnitsInStock})");
                }
            }


            //self
            //While SelectMany effectively flattens nested collections, it can introduce performance overhead in large dataset projections or translate into complex, inefficient SQL JOIN queries when used with Entity Framework.
            //Practical Alternatives:In - Memory Collections(foreach +AddRange):Iterating using a standard loop and calling List.AddRange() avoids LINQ delegate allocation overhead and improves readability.
            //Direct Entity Querying(EF Core):Querying the child collection directly(_context.Orders.ToList()) executes a straightforward SQL query without forcing an unnecessary join on the parent table.



        }

    }


    class Product02
    {
        public long ProductID { get; set; }
        public string ProductName { get; set; }
        public override string ToString()
        {
            return $"Id is {ProductID}, Name is {ProductName}";
        }
    }

    class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Salary { get; set; }

        public override string ToString()
        {
            return $"Id is {Id},Name is {Name}, Salary is {Salary}";
        }
    }

}
