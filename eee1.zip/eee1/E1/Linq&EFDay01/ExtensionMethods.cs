﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day10_G01
{
    internal static class ExtensionMethods
    {
        #region palindrome
        public static bool IsPalindrome(this string str)
        {
            if (string.IsNullOrEmpty(str))
                return false;

            string cleanedStr = str.ToLower();
            int left = 0;
            int right = cleanedStr.Length - 1;
            while (left < right)
            {
                if (cleanedStr[left] != cleanedStr[right])
                {
                    return false;
                }
                left++;
                right--;
            }
            return true;
        }
        #endregion

        #region prime
        public static bool IsPrime(this int number)
        {
            if (number <= 1) { return false; }
            for (int i = 2; i * i <= number; i++)
            {
                if (number % i == 0)
                {
                    return false;
                }
            }
            return true;
        }
        #endregion

        #region sum
        public static int CustomSum(this int[] numbers)
        {
            if (numbers == null)
            { return 0; }

            int total = 0;
            foreach (int num in numbers)
            {
                total += num;
            }
            return total;
        } 
        #endregion 
    }
}
