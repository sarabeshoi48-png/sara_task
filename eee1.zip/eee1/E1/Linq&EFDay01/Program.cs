﻿using day10_G01;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Reflection.Metadata.Ecma335;
using static day10_G01.ListGenerators;

namespace Linq_EFDay01
{

    internal class Program
    {

        static void Main()
        {
            //1
            var number = 10;
            var text = "Hello";
            var price = 99.99;
            var isActive = true;
            var numbersArray = new int[] { 1, 2, 3, 4, 5 };
            Console.WriteLine(number.GetType());
            Console.WriteLine(text.GetType());
            Console.WriteLine(price.GetType());
            Console.WriteLine(isActive.GetType());
            Console.WriteLine(numbersArray.GetType());
            //2
            int studentId = 101;
            string studentName = "Sara";
            double studentGpa = 3.9;
            bool isGraduated = false;

            var varStudentId = 101;
            var varStudentName = "Sara";
            var varStudentGpa = 3.9;
            var varIsGraduated = false;

            //The compiler determines the exact variable type during compilation based on the assigned


            //3
            var product = new
            {
                Name = "Laptop",
                Price = 25000.50m,
                Quantity = 3
            };

            Console.WriteLine(product.Name);
            Console.WriteLine(product.Price);
            Console.WriteLine(product.Quantity);

            //4
            var students = new[]
            {
                new { Name="salma",Grade = 'A' },
                new { Name="Sara", Grade = 'A' },
                new { Name= "Mona",Grade = 'c' }
            };
            foreach (var student in students)
            {
                Console.WriteLine($"Student Name:{student.Name},Grade: {student.Grade}");
            }

            //5
            var order = new
            {
                OrderId = 1001,
                OrderDate = DateTime.Now,
                Customer = new
                {
                    Name = "saraaa",
                    City = "Cairo"
                }
            };
            Console.WriteLine($"Order Date:{order.OrderDate}");
            Console.WriteLine($"Customer Name: {order.Customer.Name}");
            Console.WriteLine($"Customer City: {order.Customer.City}");

            //6
            string word1 = "madam";
            string word2 = "hello";
            Console.WriteLine(word1.IsPalindrome());
            Console.WriteLine(word2.IsPalindrome());

            //7
            int n1 = 7;
            int n2 = 12;
            Console.WriteLine(n1.IsPrime());
            Console.WriteLine(n2.IsPrime());

            //8
            int[] values = { 10, 20, 30, 40, 50 };
            int totalSum = values.CustomSum();
            Console.WriteLine(totalSum);

            //9
            List<string> employees = new List<string> { "Sara", "Mona", "Mariam" };
            employees.Add("sohila");
            employees.Remove("Mona");
            string searchName = "Sara";
            bool isFound = false;
            foreach (string name in employees)
            {
                if (name == searchName)
                {
                    isFound = true;
                    break;
                }
            }
            Console.WriteLine($"Is '{searchName}' in the list? {isFound}");
            foreach (string name in employees)
            {
                Console.WriteLine(name);
            }

            //10
            List<Employee> empList = new List<Employee>
            {
                new Employee("Ahmed", 8000m),
                new Employee("Sara", 15000m),
                new Employee("Mona", 12000m),
                new Employee("Omar", 6000m),
                new Employee("Mariam", 18000m)
            };

            decimal salaryThreshold = 10000m;
            Console.WriteLine($"Employees with Salary > 10000");
            foreach (Employee emp in empList)
            {
                if (emp.Salary > salaryThreshold)
                {
                    Console.WriteLine($"Name:{emp.Name}, Salary: {emp.Salary:C}");
                }
            }

            //11
            Dictionary<string, decimal> productPrices = new Dictionary<string, decimal>();
            productPrices.Add("Laptop", 25000.00m);
            productPrices.Add("Mouse", 450.50m);
            productPrices.Add("Keyboard", 850.00m);
            productPrices.Add("Monitor", 6200.00m);
            foreach (var item in productPrices)
            {
                Console.WriteLine($"Product:{item.Key}|Price: {item.Value:C}");
            }

            //12
            Dictionary<int, string> students2 = new Dictionary<int, string>
             {
                 { 101,"Ahmed" },
                 { 102,"Sara" },
                 { 103,"Mona" },
                 { 104,"Omar" }
             };

            Console.Write("Enter Student ID to search: ");
            if (int.TryParse(Console.ReadLine(), out int searchId))
            {
                if (students2.TryGetValue(searchId, out string student2Name))
                {
                    Console.WriteLine($"Student Found! ID: {searchId},Name: {studentName}");
                }
                else
                {
                    Console.WriteLine($"No student found with ID: {searchId}");
                }
            }
            else
            {
                Console.WriteLine("Invalid ID input. Please enter a valid integer.");
            }

            //13
            Hashtable hashtable = new Hashtable();
            hashtable.Add(1, "Cairo");
            hashtable.Add("Category", "Electronics");
            hashtable.Add(102, 4500.50);
            hashtable.Add(true, "IsActive");
            foreach (DictionaryEntry entry in hashtable)
            {
                Console.WriteLine($"Key: {entry.Key} (Type: {entry.Key.GetType().Name}) | Value: {entry.Value} (Type: {entry.Value.GetType().Name})");
            }

            //14
            Dictionary<int, string> studentDict = new Dictionary<int, string>();
            studentDict.Add(101, "Sara");
            studentDict.Add(102, "Ahmed");
            string nameFromDict = studentDict[101];
            Hashtable studentHash = new Hashtable();
            studentHash.Add(101, "Sara");
            studentHash.Add(102, "Ahmed");
            string nameFromHash = (string)studentHash[101];

            //- Dictionary is Generic It provides compile-time type safety. Retreiving values does NOT require explicit casting.
            //Hashtable is Non Generic It stores keys and values as 'object'.Retrieving values requires explicit type casting(unboxing) which can lead to InvalidCastException at runtime if incorrect
           
            
    }
        #region employee
        class Employee
        {
            public string Name { get; set; }
            public decimal Salary { get; set; }

            public Employee(string name, decimal salary)
            {
                Name = name;
                Salary = salary;
            }

            public override string ToString()
            {
                return $"Name is {Name}, Salary is {Salary}";
            }

        }
        #endregion
        class Product02
        {
            public long ProductID { get; set; }
            public string ProductName { get; set; }
        }

    }
}
