﻿using ConsoleApp1.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Configuration
{
    internal class BookConfiguration : IEntityTypeConfiguration<Book>
    {
        public void Configure(EntityTypeBuilder<Book> builder)
        {
            
            builder.Property(b => b.Title)
                   .IsRequired()
                   .HasMaxLength(150);
           
            builder.Property(b => b.Price)
                   .HasColumnType("decimal(8,2)");

            builder.Property(b => b.PublishedDate)
                   .IsRequired(false);
        }
    }
}
