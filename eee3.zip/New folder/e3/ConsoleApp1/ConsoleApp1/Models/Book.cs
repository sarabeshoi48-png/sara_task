﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//EF Core automatically recognizes any property named "Id" or "EntityNameId" as the Primary Key of the table


//Because "Country" is of type string (reference type), which is nullable by default in C#
//whereas "Price" is of type decimal(value type), which is non - nullable by default unless explicitly made nullable (decimal?)
 
namespace ConsoleApp1.Models
{
    internal class Book
    {
        [Key]
        public int Id { get; set; } 

        [Required]
        [StringLength(150)]
        public string Title { get; set; } 

        [Required]
        public decimal Price { get; set; } 

        public DateTime? PublishedDate { get; set; } 
    }
}
