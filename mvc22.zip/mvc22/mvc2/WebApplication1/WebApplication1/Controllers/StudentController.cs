﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;
using WebApplication1.Models.BL;

namespace WebApplication1.Controllers
{
    public class StudentController : Controller
    {
        StudentBL studentBL = new StudentBL();
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult ShowAll()
        {
            List<Student> students = studentBL.GetAll();
            return View("ShowAll", students);
        }

        // /Student/ShowDetails?id=3
        public IActionResult ShowDetails(int id)
        {
            Student? student = studentBL.GetById(id);
            return View("ShowDetails", student);
        }
    }
}
