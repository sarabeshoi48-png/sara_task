﻿using WebApplication1.Data.DbContexts;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Models.BL
{
    public class StudentBL
    {
        SchoolDbContext context = new SchoolDbContext();

        public List<Student> GetAll()
        {
            return context.Students
                .Include(s => s.Department)
                .ToList();
        }

        public Student? GetById(int id)
        {
            return context.Students
                .Include(s => s.Department)
                .FirstOrDefault(s => s.Id == id);
        }
    }
}
