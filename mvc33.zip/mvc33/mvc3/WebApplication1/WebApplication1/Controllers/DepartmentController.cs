﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;
using WebApplication1.Models.BL;
using WebApplication1.ViewModels;

namespace WebApplication1.Controllers
{
    public class DepartmentController : Controller
    {
        DepBL depBL = new DepBL();
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult ShowAll()
        {
            List<Department> departments = depBL.GetAll();
            return View("ShowAll", departments);
        }

        // 2- ShowDetails LifeCycle: /Department/ShowDetails/1
        public IActionResult ShowDetails(int id)
        {
            Department? dept = depBL.GetById(id);
            if (dept == null)
            {
                return NotFound();
            }

            int studentsCount = dept.Students?.Count ?? 0;

            DeptDetailsViewModel vm = new DeptDetailsViewModel
            {
                DepartmentName = dept.Name,
                DepartmentState = studentsCount > 50 ? "Main" : "Branch",
                StudentsAbove25Names = dept.Students?
                    .Where(s => s.Age > 25)
                    .Select(s => s.Name)
                    .ToList() ?? new List<string>()
            };

            return View("ShowDetails", vm);
        }

        // 3A- Add LifeCycle (GET): /Department/Add
        [HttpGet]
        public IActionResult Add()
        {
            return View("Add");
        }

        // 3B- Add LifeCycle (POST): /Department/SaveAdd
        [HttpPost]
        public IActionResult SaveAdd(Department dept)
        {
            if (!string.IsNullOrWhiteSpace(dept.Name))
            {
                depBL.Add(dept);
                return RedirectToAction(nameof(ShowAll));
            }

            return View("Add", dept);
        }
    }
}
