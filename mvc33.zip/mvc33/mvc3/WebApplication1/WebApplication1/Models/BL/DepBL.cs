﻿using WebApplication1.Data.DbContexts;
using Microsoft.EntityFrameworkCore;
namespace WebApplication1.Models.BL
{
    public class DepBL
    {
        SchoolDbContext context = new SchoolDbContext();

        public List<Department> GetAll()
        {
            return context.Departments
                          .Include(d => d.Students)
                          .ToList();
        }

        public Department? GetById(int id)
        {
            return context.Departments
                          .Include(d => d.Students)
                          .FirstOrDefault(d => d.Id == id);
        }

        public void Add(Department dept)
        {
            context.Departments.Add(dept);
            context.SaveChanges();
        }
    }
}
