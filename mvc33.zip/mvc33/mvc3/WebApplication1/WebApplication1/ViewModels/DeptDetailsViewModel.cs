﻿namespace WebApplication1.ViewModels
{
    public class DeptDetailsViewModel
    {
        public string DepartmentName { get; set; } = string.Empty;
        public string DepartmentState { get; set; } = string.Empty;
        public List<string> StudentsAbove25Names { get; set; } = new List<string>();
    }
}
