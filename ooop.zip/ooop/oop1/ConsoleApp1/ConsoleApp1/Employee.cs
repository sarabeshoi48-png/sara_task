﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ConsoleApp1
{
    internal class Employee
    {
         //private int EmpId;
         private string Name;
        //private decimal Salary;

        public string GetName()
        {
            return Name;
        }

        public void SetName( string value)
        {
            Name=value;
        }

        private decimal salary;

        public decimal Salary 
        {
            get { return salary; }
            set { salary = value; }
        }

        public int MyId { get; set; }

        public override string ToString()
        {
            return $"ID: {MyId}, Name: {Name}, Salary: {salary:C}";
        }
        //p3
        //validation rules inside property/method logic to prevent internal fields from receiving invalid states.
        //Allows to modify internal business rules or structural logic without altering or breaking existing external code

    }







}
