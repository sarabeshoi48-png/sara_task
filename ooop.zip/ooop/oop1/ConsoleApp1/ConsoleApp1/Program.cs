﻿using System;
using System.Drawing;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            point p1= new point();
            point p2 = new point(5,10);

            Console.WriteLine(p1);
            Console.WriteLine(p2);

            TypeA obj = new TypeA();
            Console.WriteLine($"Internal G: {obj.G}"); 
            Console.WriteLine($"Public H: {obj.H}");  

            Employee emp1= new Employee();
            emp1.SetName("sara");
            Console.WriteLine(emp1.GetName());
            emp1.MyId = 1;
            Console.WriteLine(emp1.MyId);
            emp1.Salary = 10000;
            Console.WriteLine(emp1.Salary);

            point2 p5 = new point2(5);
            point2 p6 = new point2(10, 20); 
            Console.WriteLine($"Point5: {p5}"); 
            Console.WriteLine($"Point 6: {p6}");

            Point p19= new Point(10, 20);
            Point p18 = p19; 
            p18.X = 99;   
            Console.WriteLine($"p1: {p19}"); 
            Console.WriteLine($"p2: {p18}");

            Employee e1 = new Employee();
            e1.SetName("saraa");
            Employee e2 = e1;
            e2.SetName("mona");
            Console.WriteLine($"e1: {e1}");
            Console.WriteLine($"e2: {e2}");
            //p6
            //Structs are value types stored directly on the Stack  whereas classes are reference types  on  Heap while the reference pointer is stored on the Stack.
        }
    }
}
