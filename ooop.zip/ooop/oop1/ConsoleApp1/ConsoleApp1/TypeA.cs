﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class TypeA
    {
        private int F = 10;
        internal int G = 20;
        public int H = 30;
        public void PrintPrivateF()
        {
            Console.WriteLine($"Private F : {F}");
        }
        //p2
        //They control where a member variable,
        //property, or method can be directly referenced or modified,
        //enforcing encapsulated object boundaries.
    }
}
