﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal struct point
    {
         private int x;
         private int y;

        public int X
        {
            get { return x; }
            set { x = value; }
        }

        public int Y
        {
            get { return y; }
            set { y = value; }
        }

        //public point()
        //{
        //    x = 0;
        //    y = 0;
        //}

        public point(int _x, int _y)
        {
            x = _x;
            y = _y;
        }

        public override string ToString() 
        {
            return $"first value is{x},second is {y}";
        }

        //p1
        //Structs are value types designed to be stored directly on the Stack
        //with a lightweight, fixed memory footprint.
        //Supporting inheritance would introduce object header overhead,
        //polymorphically dynamic sizes, and complex VTables
        //that belong exclusively to reference types stored on the Heap.  

        // p5 
        //Replaces the default fully qualified type name (Namespace.TypeName) with a human-readable representation of the object's actual internal state.
    }


}
