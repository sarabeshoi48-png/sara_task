﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class point2
    {
        public int x { get; set; }
        public int y { get; set; }


        public point2(int _x)
        {
            x = _x;
            y = 0;

        }

        public point2(int _x, int _y)
        {
            x= _x;
            y= _y;

        }

        public override string ToString()
        {
            return $"({x}, {y})";
        }
       //p4
        //A struct constructor is a special member function invoked during instantiation (via new) to initialize the struct's fields and properties in Stack memory.

    }
}
